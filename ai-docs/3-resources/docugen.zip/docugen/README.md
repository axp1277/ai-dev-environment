# DocuGen (@docugen)

LangGraph-powered documentation generator for C# codebases. It pairs Tree-sitter parsing with LLM agents to deliver coverage-aware documentation with minimal manual effort.

## Usage

```bash
# install dependencies (inside the repository)
uv pip install -e .
# or: pip install -e .

# copy and edit the configuration template
cp src/modules/docugen/config/config.example.yaml config.yaml

# run the parser-led workflow (writes documentation/documentation.md)
docugen path/to/csharp/project -c config.yaml --format markdown
```

> Requires Python 3.11+, LangGraph, langchain-openai, tree-sitter bindings, and an OpenAI-compatible LLM endpoint. This repository points to the Lockheed Martin API gateway by default; start or provision the configured service before running the workflow.

The active `config.yaml` in this repository is already tuned for the parser-led workflow. It targets the Lockheed Martin OpenAI-compatible endpoint (`https://api.ai.us.lmco.com/v1`), expects an `LMCO_API_KEY` environment variable, and runs every parser-led agent (documentation, validation, summarisation, relationship mapping) against the `gpt-oss-120b` model with an extended 3000-second timeout to accommodate long generations.

## Overview

- Parser-led workflow grounds the LLM in a Tree-sitter structural snapshot before generating prose.
- LangGraph orchestrates documentation, validation, and refinement loops for each file.
- Configuration is managed through `DocuGenConfig` YAML (models, endpoints, iteration limits, outputs).
- Compatible with Ollama, OpenRouter, Together, OpenAI, or any `/v1` OpenAI-compatible API.
- Produces a project-wide `documentation.md`, per-file markdown, and coverage metrics for every C# file.

## Architecture

```mermaid
flowchart TD
    A[Source Directory] --> P["Parser Agent<br/>(Tree-sitter)"]
    P --> FC{"File Controller<br/>per file loop"}
    FC --> D["Documentation Agent<br/>LLM synthesis"]
    D --> V["Validation Agent<br/>coverage checks"]
    V -->|needs refinement| D
    V -->|complete| C[Compiler Agent]
    C --> OUT[("documentation.md<br/>+ per-file markdown")]
    FC --> MET[(Coverage metrics)]
```

### Components

- `src/modules/docugen/workflows/parser_led/agents/parser_agent.py` discovers `.cs` files and records `StructureSnapshot` objects via Tree-sitter.
- `src/modules/docugen/workflows/parser_led/agents/file_controller.py` routes each snapshot through documentation and validation, applying iterative refinements based on gaps.
- `src/modules/docugen/workflows/parser_led/agents/documentation_agent.py` and `validation_agent.py` call the configured LLM to author docs, detect omissions, and refine the result.
- `src/modules/docugen/workflows/parser_led/agents/compiler_agent.py` assembles the final documentation set (hierarchical or markdown) and emits per-file reports.
- `src/modules/docugen/shared/parsers/csharp_structure_parser.py` implements the reusable Tree-sitter parser, while `src/modules/docugen/shared/core.py` exposes configuration models and LLM helpers.

### Workflow outputs

- `documentation/documentation.md`: consolidated project documentation in the selected format.
- `documentation/files/*.md`: per-file documentation generated alongside coverage stats.
- CLI summary tables sourced from `ParserLedState.validation_results`, showing coverage %, missing elements, and iterations.

## CLI reference

The installed `docugen` entry point targets the parser-led workflow:

```
docugen DIRECTORY [--config CONFIG] [--output OUTPUT] [--model MODEL]
                  [--llm-base-url URL] [--private | --no-private]
                  [--max-iterations N] [--format {hierarchical,markdown}] [-v]
```

Key options:

- `-c, --config CONFIG`: Path to `DocuGenConfig` YAML (default `config.yaml`); CLI flags override matching fields.
- `-o, --output OUTPUT`: Output directory for generated documentation (`<directory>/documentation` by default).
- `--model MODEL`: LLM name override for documentation (falls back to `models.documentation` or the parser-led default).
- `--llm-base-url URL`: OpenAI-compatible inference endpoint (defaults to `https://api.ai.us.lmco.com/v1` via `config.yaml`, but any provider such as `http://localhost:11434/v1` for Ollama will work).
- `--private` / `--no-private`: Include or exclude private members in the coverage calculation (includes them by default).
- `--max-iterations N`: Cap refinement passes per file (defaults to `validation.max_iterations`).
- `--format`: Choose `hierarchical` (numbered outline) or `markdown` (classic Markdown layout).
- `-v, --verbose`: Enable detailed Loguru logging during execution.

The CLI prints coverage summaries and writes documentation artefacts to the selected output directory.

## Configuration

`DocuGenConfig` (see `src/modules/docugen/shared/core.py`) centralises shared settings for all workflows. The checked-in `config.yaml` is ready for the parser-led workflow and looks like this:

```yaml
llm:
  # Lockheed Martin OpenAI-compatible endpoint used by parser_led
  base_url: "https://api.ai.us.lmco.com/v1"
  api_key_env: "LMCO_API_KEY"
  timeout: 3000

models:
  # All parser-led agents share the same model for consistency
  default: "gpt-oss-120b"
  summarizer: "gpt-oss-120b"
  detailing: "gpt-oss-120b"
  relationship_mapper: "gpt-oss-120b"
  documentation: "gpt-oss-120b"
  validation: "gpt-oss-120b"

validation:
  max_iterations: 3
  min_summary_length: 50
  require_all_public_methods: true

output:
  base_path: "./docs_output"
  include_metadata: true

processing:
  parallel_files: 1
  enable_incremental: true
  supported_languages:
    - "csharp"
```

Populate `.env` with `LMCO_API_KEY` (or adjust the config to point at another provider). The parser-led workflow reads `llm.base_url`, `llm.api_key_env`, and the `models.documentation` / `models.validation` fields directly, so keep them aligned with the endpoint you intend to run against. You can inspect additional options with `python -m src.modules.docugen.workflows.parser_led.cli --help`.


## Development

- Run tests: `pytest src/modules/docugen/tests src/modules/docugen/workflows/parser_led/tests`
- Regenerate the default config template via `create_default_config` in `src/modules/docugen/shared/core.py`.
- Logging is provided by Loguru; use CLI `-v` or attach additional sinks where needed.
