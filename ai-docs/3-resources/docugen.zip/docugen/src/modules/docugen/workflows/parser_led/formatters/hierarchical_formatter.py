"""
Hierarchical Formatter - Generates numbered hierarchical documentation

Transforms documented elements into hierarchical numbered format matching
the sample template structure.

Responsibilities:
- Format with hierarchical numbering (5.x.x.x.2.x)
- Group by module/library
- Include dependencies with reasoning
- Full method signatures with types
- Namespace and inheritance info
- Public/private indicators
"""

import re
from typing import List, Dict, Tuple
from loguru import logger

from ..state import (
    FileDocumentation,
    DocumentedClass,
    DocumentedMethod,
    DocumentedProperty,
    DocumentedField,
    DocumentedEnum,
    DocumentedInterface,
    DocumentedStruct,
    ValidationResult,
    StructureSnapshot
)


def clean_text(text: str) -> str:
    """Remove special characters and clean text."""
    if not text:
        return ""

    # Remove or replace common problematic characters
    text = text.replace('\u2018', "'")
    text = text.replace('\u2019', "'")
    text = text.replace('\u201c', '"')
    text = text.replace('\u201d', '"')
    text = text.replace('\u2013', '-')
    text = text.replace('\u2014', '--')
    text = text.replace('\u2026', '...')
    text = re.sub(r'[\u200b-\u200f\ufeff]', '', text)

    return text.strip()


class HierarchicalNumbering:
    """Manages hierarchical section numbering."""

    def __init__(self, base_number: str = "5"):
        self.base = base_number
        self.counters = {}

    def get_module_number(self, module_index: int) -> str:
        """Get number for a module (5.x)."""
        return f"{self.base}.{module_index}"

    def get_section_number(self, module_num: str, section: str) -> str:
        """Get number for a section within module (5.x.x.x.1, 5.x.x.x.2)."""
        # For simplicity, use fixed section numbers
        section_map = {
            "dependencies": "1",
            "classes": "2"
        }
        return f"{module_num}.{section_map.get(section, '0')}"

    def get_class_number(self, module_num: str, class_index: int) -> str:
        """Get number for a class (5.x.x.x.2.x)."""
        return f"{module_num}.2.{class_index}"


def format_method_hierarchical(method: DocumentedMethod, method_info=None) -> str:
    """Format a method with full signature."""
    lines = []

    # Build full signature if we have type information
    if method_info and hasattr(method_info, 'parameters'):
        param_list = []
        for param in method_info.parameters:
            # Parse "type name" from string like "string input" or "Dictionary<string, int> config"
            parts = param.strip().split()
            if len(parts) >= 2:
                param_type = ' '.join(parts[:-1])  # Everything except last word
                param_name = parts[-1]              # Last word is the parameter name
            else:
                param_type = 'object'
                param_name = param
            param_list.append(f"{param_type} {param_name}")

        return_type = getattr(method_info, 'return_type', 'void')
        signature = f"**{return_type} {method.name}({', '.join(param_list)})**"
    else:
        # Fallback to simple signature
        if method.parameters:
            params = ', '.join(method.parameters.keys())
            signature = f"**{method.name}({params})**"
        else:
            signature = f"**{method.name}()**"

    # Format: - Signature: Description
    description = clean_text(method.description) if method.description else "No description available"

    # Add parameter descriptions if available
    if method.parameters:
        param_desc = []
        for param_name, param_text in method.parameters.items():
            param_desc.append(f"    {param_name}: {clean_text(param_text)}")
        if param_desc:
            description += "\n" + "\n".join(param_desc)

    # Add return description
    if method.returns:
        description += f"\n    Returns: {clean_text(method.returns)}"

    lines.append(f"- {signature}: {description}")

    return "\n".join(lines)


def format_property_hierarchical(prop: DocumentedProperty, prop_info=None) -> str:
    """Format a property with type and accessibility."""
    # Get type and accessibility
    prop_type = getattr(prop_info, 'type', 'object') if prop_info else 'object'
    is_public = getattr(prop_info, 'is_public', True) if prop_info else True
    accessibility = "public" if is_public else "private"

    description = clean_text(prop.description) if prop.description else "No description available"
    return f"- **{prop_type} {prop.name}** ({accessibility}): {description}"


def format_field_hierarchical(field: DocumentedField, field_info=None) -> str:
    """Format a field/attribute with type and accessibility."""
    # Get type and accessibility
    field_type = getattr(field_info, 'type', 'object') if field_info else 'object'
    is_public = getattr(field_info, 'is_public', True) if field_info else True
    accessibility = "public" if is_public else "private"

    description = clean_text(field.description) if field.description else "No description available"
    return f"- **{field_type} {field.name}** ({accessibility}): {description}"


def format_enum_hierarchical(
    doc_enum: DocumentedEnum,
    enum_number: str,
    snapshot: StructureSnapshot = None
) -> str:
    """Format an enum in hierarchical numbered format."""
    lines = []

    # Enum header with number
    lines.append(f"**{enum_number} {doc_enum.name} (Enum)**")
    lines.append("")

    # Namespace
    namespace = snapshot.namespace if snapshot else "Unknown"
    lines.append(f"**Namespace:** {namespace}")
    lines.append("")

    # Purpose
    if doc_enum.purpose:
        lines.append(f"**Purpose:** {clean_text(doc_enum.purpose)}")
        lines.append("")

    # Description
    if doc_enum.description:
        lines.append(clean_text(doc_enum.description))
    else:
        lines.append("No description available.")
    lines.append("")

    # Enum values
    if doc_enum.values:
        lines.append("**Values:**")
        lines.append("")

        for value_name, value_desc in sorted(doc_enum.values.items()):
            clean_desc = clean_text(value_desc) if value_desc else "No description available"
            lines.append(f"- {value_name}: {clean_desc}")

        lines.append("")

    return "\n".join(lines)


def format_interface_hierarchical(
    doc_interface: DocumentedInterface,
    interface_number: str,
    snapshot: StructureSnapshot = None
) -> str:
    """Format an interface in hierarchical numbered format."""
    lines = []

    # Interface header with number
    lines.append(f"**{interface_number} {doc_interface.name} (Interface)**")
    lines.append("")

    # Namespace
    namespace = snapshot.namespace if snapshot else "Unknown"
    lines.append(f"**Namespace:** {namespace}")
    lines.append("")

    # Purpose
    if doc_interface.purpose:
        lines.append(f"**Purpose:** {clean_text(doc_interface.purpose)}")
        lines.append("")

    # Description
    if doc_interface.description:
        lines.append(clean_text(doc_interface.description))
    else:
        lines.append("No description available.")
    lines.append("")

    # Methods
    if doc_interface.methods:
        lines.append("**Methods:**")
        lines.append("")
        for method_name, method_doc in sorted(doc_interface.methods.items()):
            lines.append(format_method_hierarchical(method_doc))
        lines.append("")

    # Properties
    if doc_interface.properties:
        lines.append("**Properties:**")
        lines.append("")
        for prop_name, prop_doc in sorted(doc_interface.properties.items()):
            lines.append(format_property_hierarchical(prop_doc))
        lines.append("")

    return "\n".join(lines)


def format_struct_hierarchical(
    doc_struct: DocumentedStruct,
    struct_number: str,
    snapshot: StructureSnapshot = None
) -> str:
    """Format a struct in hierarchical numbered format."""
    lines = []

    # Struct header with number
    lines.append(f"**{struct_number} {doc_struct.name} (Struct)**")
    lines.append("")

    # Namespace
    namespace = snapshot.namespace if snapshot else "Unknown"
    lines.append(f"**Namespace:** {namespace}")
    lines.append("")

    # Find struct info from snapshot for interface details
    if snapshot:
        struct_info = next((s for s in snapshot.structs if s.name == doc_struct.name), None)
        if struct_info and struct_info.interfaces:
            lines.append(f"**Interfaces:** {', '.join(struct_info.interfaces)}")
            lines.append("")

    # Purpose
    if doc_struct.purpose:
        lines.append(f"**Purpose:** {clean_text(doc_struct.purpose)}")
        lines.append("")

    # Description
    if doc_struct.description:
        lines.append(clean_text(doc_struct.description))
    else:
        lines.append("No description available.")
    lines.append("")

    # Fields
    if doc_struct.fields:
        lines.append("**Fields:**")
        lines.append("")

        # Get field info from snapshot if available
        field_infos = {}
        if snapshot:
            struct_info = next((s for s in snapshot.structs if s.name == doc_struct.name), None)
            if struct_info:
                for field_info in struct_info.attributes:
                    field_infos[field_info.name] = field_info

        for field_name, field_doc in sorted(doc_struct.fields.items()):
            field_info = field_infos.get(field_name)
            lines.append(format_field_hierarchical(field_doc, field_info))

        lines.append("")

    # Properties
    if doc_struct.properties:
        lines.append("**Properties:**")
        lines.append("")

        # Get property info from snapshot if available
        prop_infos = {}
        if snapshot:
            struct_info = next((s for s in snapshot.structs if s.name == doc_struct.name), None)
            if struct_info:
                for prop_info in struct_info.properties:
                    prop_infos[prop_info.name] = prop_info

        for prop_name, prop_doc in sorted(doc_struct.properties.items()):
            prop_info = prop_infos.get(prop_name)
            lines.append(format_property_hierarchical(prop_doc, prop_info))

        lines.append("")

    # Methods
    if doc_struct.methods:
        lines.append("**Methods:**")
        lines.append("")

        # Get method info from snapshot if available
        method_infos = {}
        if snapshot:
            struct_info = next((s for s in snapshot.structs if s.name == doc_struct.name), None)
            if struct_info:
                for method_info in struct_info.methods:
                    method_infos[method_info.name] = method_info

        for method_name, method_doc in sorted(doc_struct.methods.items()):
            method_info = method_infos.get(method_name)
            lines.append(format_method_hierarchical(method_doc, method_info))

        lines.append("")

    return "\n".join(lines)


def format_class_hierarchical(
    doc_class: DocumentedClass,
    class_number: str,
    snapshot: StructureSnapshot = None
) -> str:
    """Format a class in hierarchical numbered format."""
    lines = []

    # Class header with number
    lines.append(f"**{class_number} {doc_class.name}**")
    lines.append("")

    # Namespace and inheritance
    namespace = snapshot.namespace if snapshot else "Unknown"
    lines.append(f"**Namespace:** {namespace}")

    # Find class info from snapshot for inheritance details
    if snapshot:
        class_info = next((c for c in snapshot.classes if c.name == doc_class.name), None)
        if class_info:
            if class_info.base_class:
                lines.append(f"**Base class:** {class_info.base_class}")
            if class_info.interfaces:
                lines.append(f"**Interfaces:** {', '.join(class_info.interfaces)}")

    lines.append("")

    # Description
    if doc_class.description:
        lines.append(clean_text(doc_class.description))
    else:
        lines.append("No description available.")
    lines.append("")

    # Attributes/Fields
    if doc_class.fields:
        lines.append("**Attributes:**")
        lines.append("")

        # Get field info from snapshot if available
        field_infos = {}
        if snapshot:
            class_info = next((c for c in snapshot.classes if c.name == doc_class.name), None)
            if class_info:
                for field_info in class_info.attributes:
                    field_infos[field_info.name] = field_info

        for field_name, field_doc in sorted(doc_class.fields.items()):
            field_info = field_infos.get(field_name)
            lines.append(format_field_hierarchical(field_doc, field_info))

        lines.append("")

    # Properties
    if doc_class.properties:
        lines.append("**Properties:**")
        lines.append("")

        # Get property info from snapshot if available
        prop_infos = {}
        if snapshot:
            class_info = next((c for c in snapshot.classes if c.name == doc_class.name), None)
            if class_info:
                for prop_info in class_info.properties:
                    prop_infos[prop_info.name] = prop_info

        for prop_name, prop_doc in sorted(doc_class.properties.items()):
            prop_info = prop_infos.get(prop_name)
            lines.append(format_property_hierarchical(prop_doc, prop_info))

        lines.append("")

    # Methods
    if doc_class.methods:
        lines.append("**Methods:**")
        lines.append("")

        # Get method info from snapshot if available
        method_infos = {}
        if snapshot:
            class_info = next((c for c in snapshot.classes if c.name == doc_class.name), None)
            if class_info:
                for method_info in class_info.methods:
                    method_infos[method_info.name] = method_info

        for method_name, method_doc in sorted(doc_class.methods.items()):
            method_info = method_infos.get(method_name)
            lines.append(format_method_hierarchical(method_doc, method_info))

        lines.append("")

    return "\n".join(lines)


def analyze_dependency_with_llm(dependency_name: str, llm_model) -> str:
    """
    Use LLM to generate one-sentence dependency description.
    
    Args:
        dependency_name: Name of the dependency (e.g., "Prism.Wpf (v6.1.0)")
        llm_model: LLM model instance for generating descriptions
        
    Returns:
        One-sentence description of the dependency's purpose
    """
    try:
        prompt = f"""Provide a one-sentence description explaining why the dependency "{dependency_name}" would be referenced in a C# project.

Focus on its primary purpose or functionality. Be concise and specific.

Example responses:
- "Prism.Wpf (v6.1.0)" -> "Provides MVVM framework and dependency injection for WPF applications"
- "Newtonsoft.Json" -> "Enables JSON serialization and deserialization of .NET objects"
- "Microsoft.Practices.Unity" -> "Provides dependency injection container for managing object lifetime and dependencies"

Dependency: {dependency_name}

Response format: Return ONLY the one-sentence description, nothing else."""

        response = llm_model.invoke(prompt)
        content = response.content if hasattr(response, 'content') else str(response)
        
        # Clean up response - remove quotes, newlines, etc.
        description = content.strip().strip('"\'').strip()
        
        # Validate we got something reasonable
        if description and len(description) > 10:
            return description
        else:
            logger.warning(f"LLM returned short/empty description for {dependency_name}")
            return "Required dependency for functionality"
        
    except Exception as e:
        logger.warning(f"Failed to analyze dependency {dependency_name} with LLM: {e}")
        return "Required dependency for functionality"


def format_dependencies_section(
    dependencies: List[str], 
    dependency_map: Dict[str, str] = None,
    llm_model = None
) -> str:
    """
    Format dependencies section with descriptions.
    
    Args:
        dependencies: List of dependency strings
        dependency_map: Optional pre-defined dependency descriptions
        llm_model: Optional LLM model for generating descriptions
        
    Returns:
        Formatted dependency section as string
    """
    if not dependencies:
        return ""

    lines = []
    for dep in sorted(dependencies):
        # Use provided description, generate with LLM, or use default
        if dependency_map and dep in dependency_map:
            description = dependency_map[dep]
        elif llm_model:
            logger.debug(f"Generating LLM description for dependency: {dep}")
            description = analyze_dependency_with_llm(dep, llm_model)
        else:
            description = "Required dependency for functionality"

        lines.append(f"- **{dep}**: {description}")

    return "\n".join(lines)


def generate_hierarchical_documentation(
    documented_files: Dict[str, FileDocumentation],
    structure_snapshots: Dict[str, StructureSnapshot],
    validation_results: Dict[str, ValidationResult] = None,
    base_number: str = "5",
    llm_model = None
) -> str:
    """
    Generate complete hierarchical numbered documentation.
    
    Args:
        documented_files: Dictionary of file paths to FileDocumentation objects
        structure_snapshots: Dictionary of file paths to StructureSnapshot objects
        validation_results: Optional validation results for coverage tracking
        base_number: Base section number (default "5")
        llm_model: Optional LLM model for generating dependency descriptions
        
    Returns:
        Complete hierarchical documentation as formatted string
    """
    lines = []
    numbering = HierarchicalNumbering(base_number)

    # Group files by module/namespace
    modules = {}
    for file_path, file_doc in documented_files.items():
        namespace = file_doc.namespace or "Unknown"
        # Extract module name (first part of namespace)
        module = namespace.split('.')[0] if namespace else "Unknown"

        if module not in modules:
            modules[module] = []
        modules[module].append((file_path, file_doc))

    # Generate documentation for each module
    module_index = 1
    for module_name, files in sorted(modules.items()):
        module_num = numbering.get_module_number(module_index)

        # Module header
        lines.append("=" * 80)
        lines.append(f"Section {module_index}")
        lines.append("=" * 80)
        lines.append(f"**{module_num} {module_name}**")
        lines.append("")

        # Module description (could be enhanced)
        lines.append(f"Module containing {len(files)} file(s) with related functionality.")
        lines.append("")

        # Dependencies section
        lines.append(f"**{module_num}.1 Dependencies**")
        lines.append("")

        # Collect all dependencies from files in this module
        all_dependencies = set()
        for file_path, file_doc in files:
            if file_path in structure_snapshots:
                snapshot = structure_snapshots[file_path]
                all_dependencies.update(snapshot.dependencies)

        if all_dependencies:
            lines.append(format_dependencies_section(
                list(all_dependencies),
                llm_model=llm_model
            ))
        else:
            lines.append("No external dependencies.")

        lines.append("")

        # Classes and Enums section
        lines.append(f"**{module_num}.2 Classes, Interfaces, Enums, and Structs**")
        lines.append("")

        # Document all types together (sorted by name)
        class_index = 1
        for file_path, file_doc in sorted(files):
            snapshot = structure_snapshots.get(file_path)

            # Document interfaces
            for interface_name, interface_doc in sorted(file_doc.interfaces.items()):
                interface_num = numbering.get_class_number(module_num, class_index)
                lines.append(format_interface_hierarchical(interface_doc, interface_num, snapshot))
                class_index += 1

            # Document structs
            for struct_name, struct_doc in sorted(file_doc.structs.items()):
                struct_num = numbering.get_class_number(module_num, class_index)
                lines.append(format_struct_hierarchical(struct_doc, struct_num, snapshot))
                class_index += 1

            # Document enums
            for enum_name, enum_doc in sorted(file_doc.enums.items()):
                enum_num = numbering.get_class_number(module_num, class_index)
                lines.append(format_enum_hierarchical(enum_doc, enum_num, snapshot))
                class_index += 1

            # Document classes
            for class_name, class_doc in sorted(file_doc.classes.items()):
                class_num = numbering.get_class_number(module_num, class_index)
                lines.append(format_class_hierarchical(class_doc, class_num, snapshot))
                class_index += 1

        module_index += 1
        lines.append("")

    return "\n".join(lines)


# Export formatters
__all__ = [
    "generate_hierarchical_documentation",
    "format_class_hierarchical",
    "format_interface_hierarchical",
    "format_struct_hierarchical",
    "format_enum_hierarchical",
    "format_method_hierarchical",
    "format_property_hierarchical",
    "format_field_hierarchical",
    "format_dependencies_section",
    "clean_text"
]
