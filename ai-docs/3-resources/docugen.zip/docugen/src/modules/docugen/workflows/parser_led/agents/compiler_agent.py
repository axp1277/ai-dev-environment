"""
Compiler Agent - Final Documentation Assembly

Compiles all validated documentation into final markdown output.

Responsibilities:
- Aggregate all validated file documentation
- Generate table of contents
- Apply consistent formatting
- Create summary metrics
- Export to markdown file
"""

from pathlib import Path
from datetime import datetime
import json
from loguru import logger

from ..state import ParserLedState
from ..formatters.hierarchical_formatter import generate_hierarchical_documentation
from ..formatters.markdown_formatter import (
    format_file_documentation,
    generate_table_of_contents,
    generate_summary_metrics
)
from ....shared.core import create_chat_model


def generate_json_output(state: ParserLedState) -> dict:
    """
    Generate JSON structured output from workflow state.
    
    This JSON can be used for:
    - Validating documentation.md completeness
    - Programmatic access to documentation elements
    - Testing and quality assurance
    - Integration with other tools
    
    Args:
        state: Current workflow state with all documentation
        
    Returns:
        Dictionary containing all documentation data in structured format
    """
    # Calculate summary metrics
    total_files = len(state.validation_results) if state.validation_results else 0
    complete_files = sum(1 for v in state.validation_results.values() if v.is_complete) if state.validation_results else 0
    avg_coverage = (
        sum(v.coverage_percentage for v in state.validation_results.values()) / total_files 
        if total_files > 0 else 0.0
    )
    total_elements = sum(v.total_elements for v in state.validation_results.values()) if state.validation_results else 0
    documented_elements = sum(v.documented_elements for v in state.validation_results.values()) if state.validation_results else 0
    
    # Build JSON structure
    json_output = {
        "metadata": {
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "source_directory": state.directory_path,
            "output_format": state.config.output_format if state.config else "hierarchical",
            "total_files": total_files,
            "complete_files": complete_files,
            "average_coverage": round(avg_coverage, 2),
            "total_elements": total_elements,
            "documented_elements": documented_elements,
            "missing_elements": total_elements - documented_elements
        },
        "files": {},
        "validation": {},
        "structure_snapshots": {}
    }
    
    # Add documented files (using Pydantic's model_dump for serialization)
    for file_path, file_doc in state.documented_files.items():
        json_output["files"][file_path] = file_doc.model_dump()
    
    # Add validation results
    for file_path, validation_result in (state.validation_results or {}).items():
        json_output["validation"][file_path] = validation_result.model_dump()
    
    # Add structure snapshots (parsed structure information)
    for file_path, snapshot in (state.structure_snapshots or {}).items():
        json_output["structure_snapshots"][file_path] = snapshot.model_dump()
    
    return json_output


def generate_coverage_markdown(state: ParserLedState) -> str:
    """
    Generate markdown coverage report from validation results.
    
    Args:
        state: Current workflow state with validation results
        
    Returns:
        Markdown formatted coverage report
    """
    lines = []
    
    # Header
    lines.append("# Documentation Coverage Report")
    lines.append("")
    lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"**Source Directory:** `{state.directory_path}`")
    lines.append("")
    lines.append("---")
    lines.append("")
    
    # Summary Statistics
    if state.validation_results:
        total_files = len(state.validation_results)
        complete_files = sum(1 for v in state.validation_results.values() if v.is_complete)
        avg_coverage = sum(v.coverage_percentage for v in state.validation_results.values()) / total_files if total_files > 0 else 0
        total_elements = sum(v.total_elements for v in state.validation_results.values())
        documented_elements = sum(v.documented_elements for v in state.validation_results.values())
        missing_elements = total_elements - documented_elements
        
        lines.append("## Summary Statistics")
        lines.append("")
        lines.append("| Metric | Value |")
        lines.append("|--------|-------|")
        lines.append(f"| Total Files | {total_files} |")
        lines.append(f"| Complete Files | {complete_files} ({complete_files/total_files*100:.0f}%) |")
        lines.append(f"| Average Coverage | {avg_coverage:.1f}% |")
        lines.append(f"| Total Elements | {total_elements} |")
        lines.append(f"| Documented Elements | {documented_elements} |")
        lines.append(f"| Missing Elements | {missing_elements} |")
        lines.append("")
        lines.append("---")
        lines.append("")
        
        # Per-File Coverage
        lines.append("## Per-File Coverage")
        lines.append("")
        lines.append("| File | Coverage | Elements | Status |")
        lines.append("|------|----------|----------|--------|")
        
        for file_path in sorted(state.validation_results.keys()):
            validation = state.validation_results[file_path]
            
            coverage_str = f"{validation.coverage_percentage:.1f}%"
            elements_str = f"{validation.documented_elements}/{validation.total_elements}"
            
            if validation.is_complete:
                status = "✓ Complete"
            else:
                status = f"⚠ {validation.missing_elements} gaps"
            
            lines.append(f"| {file_path} | {coverage_str} | {elements_str} | {status} |")
        
        lines.append("")
    else:
        lines.append("No validation results available.")
        lines.append("")
    
    return "\n".join(lines)


def compiler_agent_node(state: ParserLedState, output_path: str = None) -> ParserLedState:
    """
    Compiler Agent LangGraph Node - Assembles final documentation.

    Compiles all validated documentation into markdown files.

    Args:
        state: Current workflow state with documented_files and validation_results
        output_path: Optional custom output path

    Returns:
        Updated state with final_documentation path
    """
    logger.info(
        "Starting Compiler Agent",
        files=len(state.documented_files),
        output_format=state.config.output_format
    )

    if not state.documented_files:
        logger.warning("No documented files to compile")
        return state

    # Determine output directory
    if output_path is None:
        output_dir = Path(state.directory_path) / "documentation"
    else:
        output_dir = Path(output_path)

    output_dir.mkdir(parents=True, exist_ok=True)

    # Generate timestamp
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Check output format from config
    output_format = state.config.output_format if state.config else "hierarchical"

    # Build complete documentation based on format
    if output_format == "hierarchical":
        # Use hierarchical numbered format
        content = []

        # Header
        content.append("=" * 80)
        content.append("CODE DOCUMENTATION")
        content.append("=" * 80)
        content.append(f"Generated: {timestamp}")
        content.append(f"Source Directory: {state.directory_path}")
        content.append("")

        # Create LLM model for dependency descriptions
        llm_model = None
        try:
            llm_model = create_chat_model(
                base_url=state.config.llm_base_url,
                model_name=state.config.llm_model,
                api_key_env=state.config.llm_api_key_env,
                timeout=state.config.llm_timeout
            )
            logger.info("LLM model created for dependency descriptions")
        except Exception as e:
            logger.warning(f"Failed to create LLM model for dependency descriptions: {e}")
            logger.warning("Will use default descriptions for dependencies")

        # Generate hierarchical documentation
        hierarchical_doc = generate_hierarchical_documentation(
            documented_files=state.documented_files,
            structure_snapshots=state.structure_snapshots,
            validation_results=state.validation_results,
            base_number="5",
            llm_model=llm_model
        )
        content.append(hierarchical_doc)

        full_markdown = "\n".join(content)
    else:
        # Use original markdown format
        markdown_content = []

        # Header
        markdown_content.append(f"# Code Documentation")
        markdown_content.append("")
        markdown_content.append(f"**Generated:** {timestamp}")
        markdown_content.append(f"**Source Directory:** `{state.directory_path}`")
        markdown_content.append("")
        markdown_content.append("---")
        markdown_content.append("")

        # Summary metrics
        if state.validation_results:
            markdown_content.append(generate_summary_metrics(state.validation_results))
            markdown_content.append("---")
            markdown_content.append("")

        # Table of contents
        markdown_content.append(generate_table_of_contents(state.documented_files))
        markdown_content.append("---")
        markdown_content.append("")

        # Individual file documentation
        markdown_content.append("# Detailed Documentation")
        markdown_content.append("")

        for file_path in sorted(state.documented_files.keys()):
            file_doc = state.documented_files[file_path]
            validation_result = state.validation_results.get(file_path)

            # Add file documentation
            file_markdown = format_file_documentation(file_doc, validation_result)
            markdown_content.append(file_markdown)
            markdown_content.append("")
            markdown_content.append("---")
            markdown_content.append("")

        # Combine all content
        full_markdown = "\n".join(markdown_content)

    # Write to file
    output_file = output_dir / "documentation.md"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(full_markdown)

    logger.info(
        "Documentation compiled successfully",
        output_file=str(output_file),
        size=f"{len(full_markdown) / 1024:.1f} KB"
    )

    # Also create per-file documentation (optional)
    per_file_dir = output_dir / "files"
    per_file_dir.mkdir(exist_ok=True)

    for file_path, file_doc in state.documented_files.items():
        validation_result = state.validation_results.get(file_path)

        # Create markdown for this file
        file_markdown = format_file_documentation(file_doc, validation_result)

        # Determine output filename
        safe_filename = file_path.replace('/', '_').replace('\\', '_')
        output_filename = per_file_dir / f"{safe_filename}.md"

        with open(output_filename, 'w', encoding='utf-8') as f:
            f.write(file_markdown)

    logger.info(
        "Per-file documentation created",
        files=len(state.documented_files),
        directory=str(per_file_dir)
    )

    # Generate and save coverage report
    if state.validation_results:
        coverage_markdown = generate_coverage_markdown(state)
        coverage_file = output_dir / "coverage.md"
        
        with open(coverage_file, 'w', encoding='utf-8') as f:
            f.write(coverage_markdown)
        
        logger.info(
            "Coverage report created",
            output_file=str(coverage_file)
        )

    # Generate and save JSON output
    try:
        json_output = generate_json_output(state)
        json_file = output_dir / "documentation.json"
        
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(json_output, f, indent=2, ensure_ascii=False)
        
        logger.info(
            "JSON documentation created",
            output_file=str(json_file),
            size=f"{json_file.stat().st_size / 1024:.1f} KB"
        )
    except Exception as e:
        logger.error(f"Failed to generate JSON output: {e}", exc_info=True)
        logger.warning("Continuing without JSON output")

    # Update state with output path
    # We'll add this to the state model later if needed
    # For now, just log it
    logger.info(f"Final documentation available at: {output_file}")
    logger.info(f"JSON documentation available at: {output_dir / 'documentation.json'}")

    return state


# Export for LangGraph graph construction
__all__ = [
    "compiler_agent_node"
]
