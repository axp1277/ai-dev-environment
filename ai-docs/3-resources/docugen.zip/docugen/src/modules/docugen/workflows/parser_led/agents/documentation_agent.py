"""
Documentation Agent - Layer 1 (Element Documentation)

Documents each code element identified by the parser using LLM.
Takes parsed structure and generates human-readable documentation.

Responsibilities:
- Iterate through each class in StructureSnapshot
- For each element (class, method, property, field), generate documentation
- Maintain full file context in each LLM prompt
- Parse and validate LLM responses
- Aggregate all documented elements per file
- Handle LLM errors gracefully
"""

import json
from pathlib import Path
from typing import Optional, Dict
from loguru import logger

from ..state import (
    ParserLedState,
    FileDocumentation,
    DocumentedClass,
    DocumentedMethod,
    DocumentedProperty,
    DocumentedField,
    DocumentedEnum,
    DocumentedInterface,
    DocumentedStruct
)
from ....shared.parsers.csharp_structure_parser import (
    StructureSnapshot,
    ClassInfo,
    MethodInfo,
    PropertyInfo,
    AttributeInfo,
    EnumInfo,
    InterfaceInfo,
    StructInfo
)
from ....shared.core import create_chat_model


def load_prompt_template() -> str:
    """Load the element documentation prompt template."""
    prompt_path = Path(__file__).parent.parent / "prompts" / "element_documenter.md"
    with open(prompt_path, 'r', encoding='utf-8') as f:
        return f.read()


def document_method(
    method: MethodInfo,
    file_content: str,
    llm_model,
    class_name: str
) -> Optional[DocumentedMethod]:
    """
    Generate documentation for a method using LLM.

    Args:
        method: MethodInfo from parser
        file_content: Full file source code
        llm_model: LLM model instance
        class_name: Name of the containing class

    Returns:
        DocumentedMethod or None if LLM fails
    """
    try:
        # Build method signature
        params_str = ", ".join(method.parameters) if method.parameters else ""
        signature = f"{method.return_type} {method.name}({params_str})"

        # Load and format prompt
        template = load_prompt_template()
        prompt = template.format(
            element_type="Method",
            element_name=method.name,
            element_signature=signature,
            file_content=file_content
        )

        # Call LLM
        logger.debug(f"Documenting method: {class_name}.{method.name}")
        response = llm_model.invoke(prompt)

        # Parse JSON response
        content = response.content if hasattr(response, 'content') else str(response)

        # Extract JSON from markdown code blocks if present
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()

        # Try to parse JSON
        try:
            doc_data = json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(
                f"Failed to parse JSON for method {class_name}.{method.name}",
                error=str(e),
                content_preview=content[:200]
            )
            raise

        return DocumentedMethod(
            name=method.name,
            description=doc_data.get("description", ""),
            parameters=doc_data.get("parameters", {}),
            returns=doc_data.get("returns")
        )

    except Exception as e:
        logger.error(
            f"Failed to document method {class_name}.{method.name}: {e}",
            method=method.name,
            error=str(e)
        )
        return None


def document_property(
    prop: PropertyInfo,
    file_content: str,
    llm_model,
    class_name: str
) -> Optional[DocumentedProperty]:
    """
    Generate documentation for a property using LLM.

    Args:
        prop: PropertyInfo from parser
        file_content: Full file source code
        llm_model: LLM model instance
        class_name: Name of the containing class

    Returns:
        DocumentedProperty or None if LLM fails
    """
    try:
        signature = f"{prop.type} {prop.name}"

        template = load_prompt_template()
        prompt = template.format(
            element_type="Property",
            element_name=prop.name,
            element_signature=signature,
            file_content=file_content
        )

        logger.debug(f"Documenting property: {class_name}.{prop.name}")
        response = llm_model.invoke(prompt)

        content = response.content if hasattr(response, 'content') else str(response)

        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()

        doc_data = json.loads(content)

        return DocumentedProperty(
            name=prop.name,
            description=doc_data.get("description", "")
        )

    except Exception as e:
        logger.error(
            f"Failed to document property {class_name}.{prop.name}: {e}",
            property=prop.name,
            error=str(e)
        )
        return None


def document_field(
    field: AttributeInfo,
    file_content: str,
    llm_model,
    class_name: str
) -> Optional[DocumentedField]:
    """
    Generate documentation for a field using LLM.

    Args:
        field: AttributeInfo from parser
        file_content: Full file source code
        llm_model: LLM model instance
        class_name: Name of the containing class

    Returns:
        DocumentedField or None if LLM fails
    """
    try:
        signature = f"{field.type} {field.name}"

        template = load_prompt_template()
        prompt = template.format(
            element_type="Field",
            element_name=field.name,
            element_signature=signature,
            file_content=file_content
        )

        logger.debug(f"Documenting field: {class_name}.{field.name}")
        response = llm_model.invoke(prompt)

        content = response.content if hasattr(response, 'content') else str(response)

        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()

        doc_data = json.loads(content)

        return DocumentedField(
            name=field.name,
            description=doc_data.get("description", "")
        )

    except Exception as e:
        logger.error(
            f"Failed to document field {class_name}.{field.name}: {e}",
            field=field.name,
            error=str(e)
        )
        return None


def document_enum(
    enum_info: EnumInfo,
    file_content: str,
    llm_model
) -> Optional[DocumentedEnum]:
    """
    Generate documentation for an enum using LLM.

    Args:
        enum_info: EnumInfo from parser
        file_content: Full file source code
        llm_model: LLM model instance

    Returns:
        DocumentedEnum or None if LLM fails
    """
    try:
        logger.info(f"Documenting enum: {enum_info.name}")

        # Build enum signature
        values_str = ", ".join(enum_info.values) if enum_info.values else "no values"
        signature = f"enum {enum_info.name} {{ {values_str} }}"

        # Load and format prompt
        template = load_prompt_template()
        prompt = template.format(
            element_type="Enum",
            element_name=enum_info.name,
            element_signature=signature,
            file_content=file_content
        )

        logger.debug(f"Calling LLM for enum {enum_info.name}")
        response = llm_model.invoke(prompt)
        content = response.content if hasattr(response, 'content') else str(response)

        # Extract JSON from markdown code blocks if present
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()

        # Parse JSON
        try:
            doc_data = json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(
                f"Failed to parse JSON for enum {enum_info.name}",
                error=str(e),
                content_preview=content[:200]
            )
            raise

        return DocumentedEnum(
            name=enum_info.name,
            description=doc_data.get("description", ""),
            purpose=doc_data.get("purpose", ""),
            values=doc_data.get("values", {})
        )

    except Exception as e:
        logger.error(
            f"Failed to document enum {enum_info.name}: {e}",
            enum_name=enum_info.name,
            error=str(e)
        )
        return None


def document_interface(
    interface_info: InterfaceInfo,
    file_content: str,
    llm_model
) -> Optional[DocumentedInterface]:
    """
    Generate documentation for an interface using LLM.

    Args:
        interface_info: InterfaceInfo from parser
        file_content: Full file source code
        llm_model: LLM model instance

    Returns:
        DocumentedInterface or None if LLM fails
    """
    try:
        logger.info(f"Documenting interface: {interface_info.name}")

        # Build interface signature
        base_str = f" : {', '.join(interface_info.base_interfaces)}" if interface_info.base_interfaces else ""
        signature = f"interface {interface_info.name}{base_str}"

        # Load and format prompt
        template = load_prompt_template()
        prompt = template.format(
            element_type="Interface",
            element_name=interface_info.name,
            element_signature=signature,
            file_content=file_content
        )

        logger.debug(f"Calling LLM for interface {interface_info.name}")
        response = llm_model.invoke(prompt)
        content = response.content if hasattr(response, 'content') else str(response)

        # Extract JSON from markdown code blocks
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()

        # Parse JSON
        try:
            doc_data = json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(
                f"Failed to parse JSON for interface {interface_info.name}",
                error=str(e),
                content_preview=content[:200]
            )
            raise

        documented_interface = DocumentedInterface(
            name=interface_info.name,
            description=doc_data.get("description", ""),
            purpose=doc_data.get("purpose", "")
        )

        # Document methods
        for method in interface_info.methods:
            doc_method = document_method(method, file_content, llm_model, interface_info.name)
            if doc_method:
                documented_interface.methods[method.name] = doc_method

        # Document properties
        for prop in interface_info.properties:
            doc_prop = document_property(prop, file_content, llm_model, interface_info.name)
            if doc_prop:
                documented_interface.properties[prop.name] = doc_prop

        return documented_interface

    except Exception as e:
        logger.error(
            f"Failed to document interface {interface_info.name}: {e}",
            interface_name=interface_info.name,
            error=str(e)
        )
        return None


def document_struct(
    struct_info: StructInfo,
    file_content: str,
    llm_model,
    include_private: bool = True
) -> Optional[DocumentedStruct]:
    """
    Generate documentation for a struct using LLM.

    Args:
        struct_info: StructInfo from parser
        file_content: Full file source code
        llm_model: LLM model instance
        include_private: Whether to document private members

    Returns:
        DocumentedStruct or None if LLM fails
    """
    try:
        logger.info(f"Documenting struct: {struct_info.name}")

        # Build struct signature
        interfaces_str = f" : {', '.join(struct_info.interfaces)}" if struct_info.interfaces else ""
        signature = f"struct {struct_info.name}{interfaces_str}"

        # Load and format prompt
        template = load_prompt_template()
        prompt = template.format(
            element_type="Struct",
            element_name=struct_info.name,
            element_signature=signature,
            file_content=file_content
        )

        logger.debug(f"Calling LLM for struct {struct_info.name}")
        response = llm_model.invoke(prompt)
        content = response.content if hasattr(response, 'content') else str(response)

        # Extract JSON from markdown code blocks
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()

        # Parse JSON
        try:
            doc_data = json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(
                f"Failed to parse JSON for struct {struct_info.name}",
                error=str(e),
                content_preview=content[:200]
            )
            raise

        documented_struct = DocumentedStruct(
            name=struct_info.name,
            description=doc_data.get("description", ""),
            purpose=doc_data.get("purpose", "")
        )

        # Document methods
        for method in struct_info.methods:
            if not include_private and 'private' in method.modifiers:
                continue
            doc_method = document_method(method, file_content, llm_model, struct_info.name)
            if doc_method:
                documented_struct.methods[method.name] = doc_method

        # Document properties
        for prop in struct_info.properties:
            if not include_private and 'private' in prop.modifiers:
                continue
            doc_prop = document_property(prop, file_content, llm_model, struct_info.name)
            if doc_prop:
                documented_struct.properties[prop.name] = doc_prop

        # Document fields
        for field in struct_info.attributes:
            if not include_private and 'private' in field.modifiers:
                continue
            doc_field = document_field(field, file_content, llm_model, struct_info.name)
            if doc_field:
                documented_struct.fields[field.name] = doc_field

        logger.info(
            f"Completed documentation for struct {struct_info.name}",
            struct_name=struct_info.name,
            methods=len(documented_struct.methods),
            properties=len(documented_struct.properties),
            fields=len(documented_struct.fields)
        )

        return documented_struct

    except Exception as e:
        logger.error(
            f"Failed to document struct {struct_info.name}: {e}",
            struct_name=struct_info.name,
            error=str(e)
        )
        return None


def document_class(
    class_info: ClassInfo,
    file_content: str,
    llm_model,
    include_private: bool = True
) -> Optional[DocumentedClass]:
    """
    Generate complete documentation for a class and all its members.

    Args:
        class_info: ClassInfo from parser
        file_content: Full file source code
        llm_model: LLM model instance
        include_private: Whether to document private members

    Returns:
        DocumentedClass with all member documentation
    """
    try:
        # Document class itself
        logger.info(f"Documenting class: {class_info.name}")

        base_str = f" : {class_info.base_class}" if class_info.base_class else ""
        interfaces_str = f", {', '.join(class_info.interfaces)}" if class_info.interfaces else ""
        signature = f"class {class_info.name}{base_str}{interfaces_str}"

        template = load_prompt_template()
        prompt = template.format(
            element_type="Class",
            element_name=class_info.name,
            element_signature=signature,
            file_content=file_content
        )

        logger.debug(f"Calling LLM for class {class_info.name} with prompt length: {len(prompt)}")
        response = llm_model.invoke(prompt)
        content = response.content if hasattr(response, 'content') else str(response)
        logger.debug(f"Received LLM response for class {class_info.name}, content length: {len(content)}, content preview: {content[:100]}")

        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()

        # Try to parse JSON
        try:
            class_doc_data = json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(
                f"Failed to parse JSON for class {class_info.name}",
                error=str(e),
                content_preview=content[:200],
                full_content=content
            )
            raise

        documented_class = DocumentedClass(
            name=class_info.name,
            description=class_doc_data.get("description", ""),
            purpose=class_doc_data.get("purpose", "")
        )

        # Document methods
        for method in class_info.methods:
            # Skip private methods if not included
            if not include_private and 'private' in method.modifiers:
                continue

            doc_method = document_method(method, file_content, llm_model, class_info.name)
            if doc_method:
                documented_class.methods[method.name] = doc_method

        # Document properties
        for prop in class_info.properties:
            if not include_private and 'private' in prop.modifiers:
                continue

            doc_prop = document_property(prop, file_content, llm_model, class_info.name)
            if doc_prop:
                documented_class.properties[prop.name] = doc_prop

        # Document fields
        for field in class_info.attributes:
            if not include_private and 'private' in field.modifiers:
                continue

            doc_field = document_field(field, file_content, llm_model, class_info.name)
            if doc_field:
                documented_class.fields[field.name] = doc_field

        logger.info(
            f"Completed documentation for {class_info.name}",
            class_name=class_info.name,
            methods=len(documented_class.methods),
            properties=len(documented_class.properties),
            fields=len(documented_class.fields)
        )

        return documented_class

    except Exception as e:
        logger.error(
            f"Failed to document class {class_info.name}: {e}",
            class_name=class_info.name,
            error=str(e)
        )
        return None


def documentation_agent_node(state: ParserLedState) -> ParserLedState:
    """
    Documentation Agent LangGraph Node - Layer 1 (Element Documentation).

    Takes parser output and generates LLM documentation for each element.

    Args:
        state: Current workflow state with structure_snapshots populated

    Returns:
        Updated state with documented_files populated
    """
    logger.info(
        "Starting Documentation Agent",
        total_files=len(state.structure_snapshots),
        llm_model=state.config.llm_model
    )

    if not state.structure_snapshots:
        logger.warning("No structure snapshots to document")
        return state

    # Create LLM model
    try:
        llm_model = create_chat_model(
            base_url=state.config.llm_base_url,
            model_name=state.config.llm_model,
            api_key_env=state.config.llm_api_key_env,
            timeout=state.config.llm_timeout
        )
    except Exception as e:
        logger.error(f"Failed to create LLM model: {e}")
        raise

    # Process each file
    total_files = len(state.structure_snapshots)
    for idx, (file_path, snapshot) in enumerate(state.structure_snapshots.items(), start=1):
        try:
            logger.info(
                f"Documenting file {idx}/{total_files}",
                file=file_path,
                progress=f"{idx}/{total_files}"
            )

            # Read file content for context
            full_path = Path(state.directory_path) / file_path
            with open(full_path, 'r', encoding='utf-8') as f:
                file_content = f.read()

            # Create file documentation
            file_doc = FileDocumentation(
                file_path=file_path,
                namespace=snapshot.namespace
            )

            # Document each class
            for class_info in snapshot.classes:
                doc_class = document_class(
                    class_info=class_info,
                    file_content=file_content,
                    llm_model=llm_model,
                    include_private=state.config.include_private_members
                )

                if doc_class:
                    file_doc.classes[class_info.name] = doc_class

            # Document each interface
            for interface_info in snapshot.interfaces:
                doc_interface = document_interface(
                    interface_info=interface_info,
                    file_content=file_content,
                    llm_model=llm_model
                )

                if doc_interface:
                    file_doc.interfaces[interface_info.name] = doc_interface

            # Document each struct
            for struct_info in snapshot.structs:
                doc_struct = document_struct(
                    struct_info=struct_info,
                    file_content=file_content,
                    llm_model=llm_model,
                    include_private=state.config.include_private_members
                )

                if doc_struct:
                    file_doc.structs[struct_info.name] = doc_struct

            # Document each enum
            for enum_info in snapshot.enums:
                doc_enum = document_enum(
                    enum_info=enum_info,
                    file_content=file_content,
                    llm_model=llm_model
                )

                if doc_enum:
                    file_doc.enums[enum_info.name] = doc_enum

            # Store file documentation
            state.documented_files[file_path] = file_doc

        except Exception as e:
            logger.error(
                f"Failed to document file {file_path}: {e}",
                file=file_path,
                error=str(e)
            )

    # Log summary
    total_classes = sum(len(doc.classes) for doc in state.documented_files.values())
    total_interfaces = sum(len(doc.interfaces) for doc in state.documented_files.values())
    total_structs = sum(len(doc.structs) for doc in state.documented_files.values())
    total_enums = sum(len(doc.enums) for doc in state.documented_files.values())
    logger.info(
        "Documentation Agent complete",
        documented_files=len(state.documented_files),
        total_classes=total_classes,
        total_interfaces=total_interfaces,
        total_structs=total_structs,
        total_enums=total_enums
    )

    return state


# Export for LangGraph graph construction
__all__ = [
    "documentation_agent_node",
    "document_class",
    "document_interface",
    "document_struct",
    "document_enum",
    "document_method",
    "document_property",
    "document_field"
]
