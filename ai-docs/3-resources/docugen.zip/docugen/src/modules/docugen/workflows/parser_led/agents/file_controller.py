"""
File Controller - Orchestrates per-file workflow

Routes each file through the documentation and validation pipeline.

Responsibilities:
- Manage file iteration from parser output
- Route each file through Documentation Agent
- Route each file through Validation Agent
- Track progress across files
- Aggregate results for final compilation
"""

from loguru import logger
from typing import Dict

from ..state import ParserLedState
from .documentation_agent import (
    document_class,
    load_prompt_template as load_doc_template
)
from .validation_agent import (
    detect_gaps,
    calculate_coverage,
    refine_missing_element,
    load_refinement_prompt_template
)
from ....shared.core import create_chat_model
from ..state import FileDocumentation, ValidationResult
from pathlib import Path


def process_single_file(
    state: ParserLedState,
    file_path: str,
    llm_model
) -> tuple:
    """
    Process a single file through documentation and validation.

    Args:
        state: Current workflow state
        file_path: Relative path to file
        llm_model: LLM instance

    Returns:
        Tuple of (FileDocumentation, ValidationResult)
    """
    logger.info(f"Processing file: {file_path}")

    if file_path not in state.structure_snapshots:
        logger.warning(f"No structure snapshot for {file_path}")
        return None, None

    snapshot = state.structure_snapshots[file_path]

    # Read file content
    full_path = Path(state.directory_path) / file_path
    with open(full_path, 'r', encoding='utf-8') as f:
        file_content = f.read()

    # Create file documentation
    file_doc = FileDocumentation(
        file_path=file_path,
        namespace=snapshot.namespace
    )

    # Document each class
    logger.info(f"Documenting {len(snapshot.classes)} classes in {file_path}")
    for class_info in snapshot.classes:
        doc_class = document_class(
            class_info=class_info,
            file_content=file_content,
            llm_model=llm_model,
            include_private=state.config.include_private_members
        )

        if doc_class:
            file_doc.classes[class_info.name] = doc_class

    # Initial validation
    gaps = detect_gaps(snapshot, file_doc, state.config.include_private_members)
    total, documented, coverage = calculate_coverage(
        snapshot, file_doc, state.config.include_private_members
    )

    logger.info(
        f"Initial documentation coverage: {coverage:.1f}%",
        file=file_path,
        gaps=len(gaps)
    )

    # Iterative refinement
    iteration = 0
    max_iterations = state.config.max_validation_iterations
    prev_gaps = gaps
    prev_coverage = coverage

    while gaps and iteration < max_iterations:
        iteration += 1
        logger.info(
            f"═══ Refinement Iteration {iteration}/{max_iterations} ═══",
            file=file_path,
            current_gaps=len(gaps),
            current_coverage=f"{coverage:.1f}%"
        )

        # Refine each gap
        for gap in gaps:
            doc_data = refine_missing_element(
                gap, snapshot, file_content, file_doc, llm_model
            )

            if doc_data:
                # Add refined documentation - handle all element types
                if gap.element_type == "class":
                    from ..state import DocumentedClass
                    file_doc.classes[gap.element_name] = DocumentedClass(
                        name=gap.element_name,
                        description=doc_data.get("description", ""),
                        purpose=doc_data.get("purpose", "")
                    )
                    logger.debug(f"Integrated class '{gap.element_name}'")
                    
                elif gap.element_type == "method" and gap.parent_class:
                    if gap.parent_class in file_doc.classes:
                        from ..state import DocumentedMethod
                        file_doc.classes[gap.parent_class].methods[gap.element_name] = DocumentedMethod(
                            name=gap.element_name,
                            description=doc_data.get("description", ""),
                            parameters=doc_data.get("parameters", {}),
                            returns=doc_data.get("returns")
                        )
                        logger.debug(f"Integrated method '{gap.element_name}' into class '{gap.parent_class}'")
                        
                elif gap.element_type == "property" and gap.parent_class:
                    if gap.parent_class in file_doc.classes:
                        from ..state import DocumentedProperty
                        file_doc.classes[gap.parent_class].properties[gap.element_name] = DocumentedProperty(
                            name=gap.element_name,
                            description=doc_data.get("description", "")
                        )
                        logger.debug(f"Integrated property '{gap.element_name}' into class '{gap.parent_class}'")
                        
                elif gap.element_type == "field" and gap.parent_class:
                    if gap.parent_class in file_doc.classes:
                        from ..state import DocumentedField
                        file_doc.classes[gap.parent_class].fields[gap.element_name] = DocumentedField(
                            name=gap.element_name,
                            description=doc_data.get("description", "")
                        )
                        logger.debug(f"Integrated field '{gap.element_name}' into class '{gap.parent_class}'")
                
                # Interface support
                elif gap.element_type == "interface":
                    from ..state import DocumentedInterface
                    file_doc.interfaces[gap.element_name] = DocumentedInterface(
                        name=gap.element_name,
                        description=doc_data.get("description", ""),
                        purpose=doc_data.get("purpose", "")
                    )
                    logger.debug(f"Integrated interface '{gap.element_name}'")
                    
                elif gap.element_type == "interface_method" and gap.parent_class:
                    if gap.parent_class in file_doc.interfaces:
                        from ..state import DocumentedMethod
                        file_doc.interfaces[gap.parent_class].methods[gap.element_name] = DocumentedMethod(
                            name=gap.element_name,
                            description=doc_data.get("description", ""),
                            parameters=doc_data.get("parameters", {}),
                            returns=doc_data.get("returns")
                        )
                        logger.debug(f"Integrated method '{gap.element_name}' into interface '{gap.parent_class}'")
                        
                elif gap.element_type == "interface_property" and gap.parent_class:
                    if gap.parent_class in file_doc.interfaces:
                        from ..state import DocumentedProperty
                        file_doc.interfaces[gap.parent_class].properties[gap.element_name] = DocumentedProperty(
                            name=gap.element_name,
                            description=doc_data.get("description", "")
                        )
                        logger.debug(f"Integrated property '{gap.element_name}' into interface '{gap.parent_class}'")
                
                # Struct support
                elif gap.element_type == "struct":
                    from ..state import DocumentedStruct
                    file_doc.structs[gap.element_name] = DocumentedStruct(
                        name=gap.element_name,
                        description=doc_data.get("description", ""),
                        purpose=doc_data.get("purpose", "")
                    )
                    logger.debug(f"Integrated struct '{gap.element_name}'")
                    
                elif gap.element_type == "struct_method" and gap.parent_class:
                    if gap.parent_class in file_doc.structs:
                        from ..state import DocumentedMethod
                        file_doc.structs[gap.parent_class].methods[gap.element_name] = DocumentedMethod(
                            name=gap.element_name,
                            description=doc_data.get("description", ""),
                            parameters=doc_data.get("parameters", {}),
                            returns=doc_data.get("returns")
                        )
                        logger.debug(f"Integrated method '{gap.element_name}' into struct '{gap.parent_class}'")
                        
                elif gap.element_type == "struct_property" and gap.parent_class:
                    if gap.parent_class in file_doc.structs:
                        from ..state import DocumentedProperty
                        file_doc.structs[gap.parent_class].properties[gap.element_name] = DocumentedProperty(
                            name=gap.element_name,
                            description=doc_data.get("description", "")
                        )
                        logger.debug(f"Integrated property '{gap.element_name}' into struct '{gap.parent_class}'")
                        
                elif gap.element_type == "struct_field" and gap.parent_class:
                    if gap.parent_class in file_doc.structs:
                        from ..state import DocumentedField
                        file_doc.structs[gap.parent_class].fields[gap.element_name] = DocumentedField(
                            name=gap.element_name,
                            description=doc_data.get("description", "")
                        )
                        logger.debug(f"Integrated field '{gap.element_name}' into struct '{gap.parent_class}'")
                
                # Enum support
                elif gap.element_type == "enum":
                    from ..state import DocumentedEnum
                    file_doc.enums[gap.element_name] = DocumentedEnum(
                        name=gap.element_name,
                        description=doc_data.get("description", ""),
                        purpose=doc_data.get("purpose", ""),
                        values=doc_data.get("values", {})
                    )
                    logger.debug(f"Integrated enum '{gap.element_name}'")
                    
                elif gap.element_type == "enum_value" and gap.parent_class:
                    if gap.parent_class in file_doc.enums:
                        file_doc.enums[gap.parent_class].values[gap.element_name] = doc_data.get("description", "")
                        logger.debug(f"Integrated enum value '{gap.element_name}' into enum '{gap.parent_class}'")

        # Re-validate
        prev_gaps_count = len(prev_gaps)
        prev_documented = documented
        
        gaps = detect_gaps(snapshot, file_doc, state.config.include_private_members)
        total, documented, coverage = calculate_coverage(
            snapshot, file_doc, state.config.include_private_members
        )

        # Calculate deltas
        gap_reduction = prev_gaps_count - len(gaps)
        elements_added = documented - prev_documented
        coverage_delta = coverage - prev_coverage

        logger.info(
            f"Iteration {iteration} complete",
            coverage=f"{coverage:.1f}%",
            gaps_remaining=len(gaps),
            gaps_filled=gap_reduction,
            file=file_path
        )
        
        # Log coverage comparison
        logger.info(
            f"Refinement impact",
            coverage_change=f"{prev_coverage:.1f}% → {coverage:.1f}% (+{coverage_delta:.1f}%)",
            elements_added=elements_added,
            file=file_path
        )

        if not gaps:
            logger.success(
                f"🎉 Achieved 100% coverage for {file_path}",
                iterations=iteration,
                total_elements=total
            )
            break
        
        # Update prev values for next iteration
        prev_gaps = gaps
        prev_coverage = coverage
    
    # Check if max iterations reached with remaining gaps
    if iteration >= max_iterations and gaps:
        logger.warning(
            f"⚠️  Max iterations ({max_iterations}) reached with {len(gaps)} remaining gaps",
            file=file_path,
            final_coverage=f"{coverage:.1f}%"
        )

    # Create final validation result
    validation_result = ValidationResult(
        file_path=file_path,
        iteration=iteration,
        coverage_percentage=coverage,
        total_elements=total,
        documented_elements=documented,
        missing_elements=len(gaps),
        gaps=gaps,
        is_complete=(len(gaps) == 0)
    )

    logger.info(
        f"Completed {file_path}",
        coverage=f"{coverage:.1f}%",
        iterations=iteration,
        complete=validation_result.is_complete
    )

    return file_doc, validation_result


def file_controller_node(state: ParserLedState) -> ParserLedState:
    """
    File Controller LangGraph Node - Orchestrates per-file workflow.

    Manages iteration through files and routes each through the pipeline.

    Args:
        state: Current workflow state with structure_snapshots

    Returns:
        Updated state with documented_files and validation_results
    """
    logger.info(
        "Starting File Controller",
        total_files=len(state.structure_snapshots)
    )

    if not state.structure_snapshots:
        logger.warning("No files to process")
        return state

    # Create LLM model once for all files
    try:
        llm_model = create_chat_model(
            base_url=state.config.llm_base_url,
            model_name=state.config.llm_model,
            api_key_env=state.config.llm_api_key_env,
            timeout=state.config.llm_timeout
        )
    except Exception as e:
        logger.error(f"Failed to create LLM model: {e}")
        raise

    # Process each file
    total_files = len(state.structure_snapshots)
    completed_files = 0

    for idx, file_path in enumerate(state.structure_snapshots.keys(), start=1):
        logger.info(f"Processing file {idx}/{total_files}: {file_path}")

        try:
            file_doc, validation_result = process_single_file(
                state, file_path, llm_model
            )

            if file_doc and validation_result:
                state.documented_files[file_path] = file_doc
                state.validation_results[file_path] = validation_result
                completed_files += 1

        except Exception as e:
            logger.error(
                f"Failed to process {file_path}: {e}",
                file=file_path,
                error=str(e)
            )
            # Continue with other files

    # Calculate summary metrics
    complete_count = sum(1 for v in state.validation_results.values() if v.is_complete)
    avg_coverage = sum(v.coverage_percentage for v in state.validation_results.values()) / len(state.validation_results) if state.validation_results else 0

    logger.info(
        "File Controller complete",
        completed=completed_files,
        total=total_files,
        complete_files=complete_count,
        avg_coverage=f"{avg_coverage:.1f}%"
    )

    return state


# Export for LangGraph graph construction
__all__ = [
    "file_controller_node",
    "process_single_file"
]
