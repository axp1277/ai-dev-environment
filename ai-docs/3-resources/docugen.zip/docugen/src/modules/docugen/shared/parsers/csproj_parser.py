"""
C# Project File (.csproj) Parser

This module provides functionality to parse .csproj files and extract dependency information,
including NuGet packages and project references.
"""

from typing import List, Dict, Optional
from pathlib import Path
from pydantic import BaseModel, Field
import xml.etree.ElementTree as ET


class NuGetPackage(BaseModel):
    """Represents a NuGet package dependency."""
    name: str
    version: Optional[str] = None
    
    class Config:
        """Pydantic configuration."""
        frozen = False


class ProjectReference(BaseModel):
    """Represents a project reference dependency."""
    name: str  # Project name extracted from path
    path: str  # Relative path to the .csproj file
    guid: Optional[str] = None  # Project GUID if available
    
    class Config:
        """Pydantic configuration."""
        frozen = False


class ProjectDependencies(BaseModel):
    """Complete dependency information from a .csproj file."""
    project_name: str
    nuget_packages: List[NuGetPackage] = Field(default_factory=list)
    project_references: List[ProjectReference] = Field(default_factory=list)
    target_framework: Optional[str] = None  # e.g., "net472", "netstandard2.0"
    
    class Config:
        """Pydantic configuration."""
        frozen = False


class CsProjParser:
    """
    Parser for extracting dependency information from .csproj files.
    
    Supports both old-style (.NET Framework) and new-style (SDK-style) .csproj formats.
    """
    
    def __init__(self):
        """Initialize the parser."""
        pass
    
    def parse_file(self, csproj_path: str) -> ProjectDependencies:
        """
        Parse a .csproj file and extract dependency information.
        
        Args:
            csproj_path: Path to the .csproj file
            
        Returns:
            ProjectDependencies containing all dependency information
        """
        csproj_file = Path(csproj_path)
        
        if not csproj_file.exists():
            raise FileNotFoundError(f"Project file not found: {csproj_path}")
        
        # Extract project name from filename
        project_name = csproj_file.stem
        
        # Parse XML
        try:
            tree = ET.parse(csproj_file)
            root = tree.getroot()
        except ET.ParseError as e:
            raise ValueError(f"Failed to parse .csproj file: {e}")
        
        # Extract dependencies
        nuget_packages = self._extract_nuget_packages(root)
        project_references = self._extract_project_references(root, csproj_file.parent)
        target_framework = self._extract_target_framework(root)
        
        return ProjectDependencies(
            project_name=project_name,
            nuget_packages=nuget_packages,
            project_references=project_references,
            target_framework=target_framework
        )
    
    def _extract_nuget_packages(self, root: ET.Element) -> List[NuGetPackage]:
        """
        Extract NuGet package dependencies from the project XML.
        
        Handles both:
        - PackageReference elements (SDK-style and some .NET Framework projects)
        - packages.config references (older .NET Framework projects)
        """
        packages = []
        
        # Look for PackageReference elements
        # These can be in ItemGroup elements with or without namespace
        for item_group in root.findall(".//{*}ItemGroup"):
            for package_ref in item_group.findall("{*}PackageReference"):
                name = package_ref.get("Include")
                version = package_ref.get("Version")
                
                # Version might also be in a child element
                if not version:
                    version_elem = package_ref.find("{*}Version")
                    if version_elem is not None:
                        version = version_elem.text
                
                if name:
                    packages.append(NuGetPackage(
                        name=name,
                        version=version
                    ))
        
        # Also look for Reference elements with HintPath (older format)
        for item_group in root.findall(".//{*}ItemGroup"):
            for ref in item_group.findall("{*}Reference"):
                include = ref.get("Include")
                hint_path = ref.find("{*}HintPath")
                
                # Check if this is a NuGet package (hint path contains "packages")
                if include and hint_path is not None:
                    hint_path_text = hint_path.text
                    if hint_path_text and "packages" in hint_path_text.lower():
                        # Extract package name from Include attribute
                        # Format is usually "PackageName, Version=x.x.x, ..."
                        package_name = include.split(',')[0].strip()
                        
                        # Try to extract version from HintPath
                        # Format is usually: ..\packages\PackageName.x.x.x\lib\...
                        version = None
                        try:
                            parts = hint_path_text.split('\\')
                            for part in parts:
                                if part.startswith(package_name + '.'):
                                    version = part[len(package_name) + 1:]
                                    break
                        except:
                            pass
                        
                        packages.append(NuGetPackage(
                            name=package_name,
                            version=version
                        ))
        
        return packages
    
    def _extract_project_references(self, root: ET.Element, base_path: Path) -> List[ProjectReference]:
        """
        Extract project reference dependencies from the project XML.
        
        Args:
            root: XML root element
            base_path: Base directory of the .csproj file (for resolving relative paths)
        """
        references = []
        
        # Look for ProjectReference elements
        for item_group in root.findall(".//{*}ItemGroup"):
            for proj_ref in item_group.findall("{*}ProjectReference"):
                include_path = proj_ref.get("Include")
                
                if not include_path:
                    continue
                
                # Extract project name from path
                # Path format: ..\ProjectName\ProjectName.csproj
                ref_path = Path(include_path)
                project_name = ref_path.stem
                
                # Extract GUID if available
                guid = None
                project_elem = proj_ref.find("{*}Project")
                if project_elem is not None:
                    guid = project_elem.text
                
                references.append(ProjectReference(
                    name=project_name,
                    path=include_path,
                    guid=guid
                ))
        
        return references
    
    def _extract_target_framework(self, root: ET.Element) -> Optional[str]:
        """
        Extract the target framework from the project XML.
        
        Returns the first target framework found (some projects may target multiple).
        """
        # SDK-style: TargetFramework or TargetFrameworks
        for prop_group in root.findall(".//{*}PropertyGroup"):
            # Single target framework
            target_fw = prop_group.find("{*}TargetFramework")
            if target_fw is not None and target_fw.text:
                return target_fw.text
            
            # Multiple target frameworks (take the first one)
            target_fws = prop_group.find("{*}TargetFrameworks")
            if target_fws is not None and target_fws.text:
                frameworks = target_fws.text.split(';')
                if frameworks:
                    return frameworks[0].strip()
            
            # Old-style: TargetFrameworkVersion
            target_fw_version = prop_group.find("{*}TargetFrameworkVersion")
            if target_fw_version is not None and target_fw_version.text:
                # Convert format like "v4.7.2" to "net472"
                version = target_fw_version.text.replace('v', '').replace('.', '')
                return f"net{version}"
        
        return None
    
    def get_all_dependencies_as_strings(self, dependencies: ProjectDependencies) -> List[str]:
        """
        Convert all dependencies to a flat list of strings for easy inclusion in StructureSnapshot.
        
        Format:
        - NuGet packages: "PackageName (v1.2.3)"
        - Project references: "ProjectName (project)"
        
        Args:
            dependencies: ProjectDependencies object
            
        Returns:
            List of dependency strings
        """
        result = []
        
        # Add NuGet packages
        for package in dependencies.nuget_packages:
            if package.version:
                result.append(f"{package.name} (v{package.version})")
            else:
                result.append(f"{package.name}")
        
        # Add project references
        for ref in dependencies.project_references:
            result.append(f"{ref.name} (project)")
        
        return result


def find_csproj_for_cs_file(cs_file_path: str) -> Optional[str]:
    """
    Find the corresponding .csproj file for a given .cs file.
    
    Searches upward from the .cs file directory to find a .csproj file.
    
    Args:
        cs_file_path: Path to a C# source file
        
    Returns:
        Path to the .csproj file if found, None otherwise
    """
    cs_path = Path(cs_file_path)
    
    if not cs_path.exists():
        return None
    
    # Start from the directory containing the .cs file
    current_dir = cs_path.parent
    
    # Search upward through parent directories
    while current_dir != current_dir.parent:  # Stop at filesystem root
        # Look for any .csproj file in this directory
        csproj_files = list(current_dir.glob("*.csproj"))
        
        if csproj_files:
            # Return the first .csproj file found
            return str(csproj_files[0])
        
        # Move up one directory
        current_dir = current_dir.parent
    
    return None


# Example usage
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python csproj_parser.py <path_to_csproj>")
        sys.exit(1)
    
    parser = CsProjParser()
    dependencies = parser.parse_file(sys.argv[1])
    
    print(f"Project: {dependencies.project_name}")
    print(f"Target Framework: {dependencies.target_framework or 'Not specified'}")
    print()
    
    if dependencies.nuget_packages:
        print("NuGet Packages:")
        for package in dependencies.nuget_packages:
            version_str = f" (v{package.version})" if package.version else ""
            print(f"  - {package.name}{version_str}")
        print()
    
    if dependencies.project_references:
        print("Project References:")
        for ref in dependencies.project_references:
            print(f"  - {ref.name}")
            print(f"    Path: {ref.path}")
            if ref.guid:
                print(f"    GUID: {ref.guid}")
        print()
    
    print("All Dependencies (flat list):")
    all_deps = parser.get_all_dependencies_as_strings(dependencies)
    for dep in all_deps:
        print(f"  - {dep}")
