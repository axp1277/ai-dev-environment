"""
Parsers for extracting structure from C# code and project files.
"""

from .csharp_structure_parser import (
    CSharpStructureParser,
    StructureSnapshot,
    ClassInfo,
    InterfaceInfo,
    StructInfo,
    EnumInfo,
    MethodInfo,
    PropertyInfo,
    AttributeInfo,
)

from .csproj_parser import (
    CsProjParser,
    ProjectDependencies,
    NuGetPackage,
    ProjectReference,
    find_csproj_for_cs_file,
)

__all__ = [
    # C# Structure Parser
    "CSharpStructureParser",
    "StructureSnapshot",
    "ClassInfo",
    "InterfaceInfo",
    "StructInfo",
    "EnumInfo",
    "MethodInfo",
    "PropertyInfo",
    "AttributeInfo",
    # CsProj Parser
    "CsProjParser",
    "ProjectDependencies",
    "NuGetPackage",
    "ProjectReference",
    "find_csproj_for_cs_file",
]
