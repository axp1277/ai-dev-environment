# Chore: Add Refinement Observability Logs

## Chore Description

The parser-led workflow's gap detection and refinement process currently lacks detailed observability logs. When gaps are identified during validation, it's not clear:
- Which specific elements are missing (gaps are only counted, not listed)
- When refinement attempts begin for each gap
- Whether each refinement succeeds or fails
- What the LLM response contains (for debugging)
- Whether the refined documentation was successfully integrated

This chore adds comprehensive logging throughout the refinement cycle to provide clear observability into:
1. Gap detection results (list all identified gaps)
2. Refinement triggering (log when refinement starts for each gap)
3. LLM invocation and response (sanitized content preview)
4. Integration success/failure for each refined element
5. Iteration-level progress tracking

## Relevant Files

Use these files to resolve the chore:

- `src/modules/docugen/workflows/parser_led/agents/validation_agent.py` - **PRIMARY FILE**: Contains `detect_gaps()`, `refine_missing_element()`, and `validation_agent_node()` functions. Needs enhanced logging throughout the refinement process.
  - Add logs after gap detection to list all identified gaps
  - Add logs at start of each refinement attempt
  - Add logs showing LLM response preview
  - Add logs confirming successful integration
  - Add logs for refinement failures with context

- `src/modules/docugen/workflows/parser_led/agents/file_controller.py` - **SECONDARY FILE**: Contains `process_single_file()` which orchestrates the iteration loop. Needs logs showing iteration progress and decision points.
  - Add logs at start of each iteration
  - Add logs showing gap reduction between iterations
  - Add logs when max iterations reached
  - Add logs when 100% coverage achieved

- `README.md` - Reference for understanding Loguru logging usage and project structure

### New Files
None - this is a logging enhancement to existing code

## Step by Step Tasks

Execute every step in order, top to bottom.

### Step 1: Enhance Gap Detection Logging in validation_agent.py

- [ ] After `detect_gaps()` call in `validation_agent_node()`, add detailed gap listing log
- [ ] Include gap count, element types breakdown, and sample gaps (first 5)
- [ ] Use `logger.info()` for gap summary
- [ ] Format: `"Detected {count} gaps: {breakdown}"` where breakdown shows counts per type
- [ ] Add `logger.debug()` with full gap list for verbose mode

Example structure:
```python
# After: gaps = detect_gaps(snapshot, file_doc, state.config.include_private_members)
if gaps:
    # Count gaps by type
    gap_types = {}
    for gap in gaps:
        gap_types[gap.element_type] = gap_types.get(gap.element_type, 0) + 1
    
    gap_breakdown = ", ".join(f"{count} {type_}" for type_, count in gap_types.items())
    logger.info(
        f"Detected {len(gaps)} gaps in {file_path}",
        breakdown=gap_breakdown,
        file=file_path
    )
    
    # Log first few gaps as examples
    sample_gaps = gaps[:5]
    for gap in sample_gaps:
        parent_str = f" in {gap.parent_class}" if gap.parent_class else ""
        logger.debug(f"  Gap: {gap.element_type} '{gap.element_name}'{parent_str} - {gap.reason}")
```

### Step 2: Add Refinement Trigger Logging

- [ ] At the start of the refinement loop in `validation_agent_node()`, add iteration start log
- [ ] Before entering the `for gap in gaps:` loop, log refinement phase start
- [ ] Format: `"Starting refinement iteration {iteration}/{max} for {file_path} with {gap_count} gaps"`

Example:
```python
if gaps and current_iteration < state.config.max_validation_iterations:
    logger.info(
        f"Starting refinement iteration {current_iteration}/{state.config.max_validation_iterations}",
        file=file_path,
        gaps=len(gaps)
    )
```

### Step 3: Enhance Individual Gap Refinement Logging

- [ ] At the start of each gap refinement in the loop, add log showing which element is being refined
- [ ] After `refine_missing_element()` call, add log showing success/failure
- [ ] If `doc_data` is None, log failure with reason
- [ ] If `doc_data` exists, log success with preview of generated content
- [ ] Use `logger.info()` for refinement attempts and `logger.success()` for successful refinements

Example:
```python
for gap in gaps:
    parent_str = f" in {gap.parent_class}" if gap.parent_class else ""
    logger.info(
        f"🔄 Refining {gap.element_type} '{gap.element_name}'{parent_str}",
        element_type=gap.element_type,
        element_name=gap.element_name,
        parent=gap.parent_class
    )
    
    doc_data = refine_missing_element(
        gap, snapshot, file_content, file_doc, llm_model
    )
    
    if not doc_data:
        logger.warning(
            f"❌ Failed to refine {gap.element_type} '{gap.element_name}'{parent_str}",
            reason="LLM returned invalid or no response"
        )
        continue
    
    logger.success(
        f"✓ Refined {gap.element_type} '{gap.element_name}'{parent_str}",
        description_preview=doc_data.get("description", "")[:100] + "..." if doc_data.get("description") else "N/A"
    )
```

### Step 4: Add Integration Success Logging

- [ ] After each gap type's integration logic, add confirmation log
- [ ] Use `logger.debug()` to avoid verbosity
- [ ] Include the integration path (e.g., "Added to file_doc.classes[X].methods")

Example:
```python
if gap.element_type == "method" and gap.parent_class:
    if gap.parent_class in file_doc.classes:
        file_doc.classes[gap.parent_class].methods[gap.element_name] = DocumentedMethod(...)
        logger.debug(
            f"Integrated method '{gap.element_name}' into class '{gap.parent_class}'",
            path=f"file_doc.classes[{gap.parent_class}].methods[{gap.element_name}]"
        )
```

### Step 5: Enhance refine_missing_element() Function Logging

- [ ] Add log at start of `refine_missing_element()` showing element signature extraction
- [ ] Add log before LLM invocation showing prompt length
- [ ] Add log after LLM response showing response content preview (first 200 chars)
- [ ] Enhance existing error logs with more context (element type, signature, error type)

Example:
```python
def refine_missing_element(...) -> Optional[Dict]:
    try:
        # ... existing code to extract signature ...
        
        logger.debug(
            f"Preparing refinement prompt for {gap.element_type} '{gap.element_name}'",
            signature=element_signature[:100]
        )
        
        # ... format prompt ...
        
        logger.debug(
            f"Invoking LLM for {gap.element_type} '{gap.element_name}'",
            prompt_length=len(prompt)
        )
        
        response = llm_model.invoke(prompt)
        content = response.content if hasattr(response, 'content') else str(response)
        
        logger.debug(
            f"Received LLM response for {gap.element_type} '{gap.element_name}'",
            response_preview=content[:200].replace('\n', ' ')
        )
        
        # ... rest of function ...
```

### Step 6: Add Iteration Progress Tracking in file_controller.py

- [ ] At the start of the refinement loop in `process_single_file()`, add iteration header log
- [ ] After each iteration, log gap reduction metrics
- [ ] When 100% coverage achieved, add success log
- [ ] When max iterations reached with remaining gaps, add warning log

Example:
```python
while gaps and iteration < max_iterations:
    iteration += 1
    logger.info(
        f"═══ Refinement Iteration {iteration}/{max_iterations} ═══",
        file=file_path,
        current_gaps=len(gaps),
        current_coverage=f"{coverage:.1f}%"
    )
    
    # ... refinement logic ...
    
    # After re-validation
    gap_reduction = len(prev_gaps) - len(gaps)
    logger.info(
        f"Iteration {iteration} complete",
        coverage=f"{coverage:.1f}%",
        gaps_remaining=len(gaps),
        gaps_filled=gap_reduction,
        file=file_path
    )
    
    if not gaps:
        logger.success(
            f"🎉 Achieved 100% coverage for {file_path}",
            iterations=iteration,
            total_elements=total
        )
        break

if iteration >= max_iterations and gaps:
    logger.warning(
        f"⚠️  Max iterations ({max_iterations}) reached with {len(gaps)} remaining gaps",
        file=file_path,
        final_coverage=f"{coverage:.1f}%"
    )
```

### Step 7: Add Coverage Comparison Logging

- [ ] Before and after refinement, log coverage delta
- [ ] Show elements added count
- [ ] Show coverage percentage increase

Example:
```python
# Before refinement
prev_coverage = coverage
prev_documented = documented

# ... refinement ...

# After refinement
coverage_delta = coverage_after - prev_coverage
elements_added = documented_after - prev_documented

logger.info(
    f"Refinement impact",
    coverage_change=f"{prev_coverage:.1f}% → {coverage_after:.1f}% (+{coverage_delta:.1f}%)",
    elements_added=elements_added,
    file=file_path
)
```

### Step 8: Run Validation Commands

Execute the validation commands listed in the next section to ensure zero regressions.

## Validation Commands

Execute every command to validate the chore is complete with zero regressions.

- `pytest src/modules/docugen/workflows/parser_led/tests/test_validation_agent.py -v` - Run validation agent tests
- `pytest src/modules/docugen/workflows/parser_led/tests/ -v` - Run all parser-led workflow tests
- `pytest src/modules/docugen/tests/ -v` - Run all docugen tests to ensure no regressions
- `python -m src.modules.docugen.workflows.parser_led.cli --help` - Verify CLI still works
- Manual test: Run `docugen` on a small C# project with `-v` flag and verify new logs appear in correct sequence

## Notes

### Logging Best Practices

1. **Use appropriate log levels**:
   - `logger.debug()` - Detailed diagnostic info (prompt lengths, response previews, integration paths)
   - `logger.info()` - General progress updates (gap detection, iteration starts, coverage metrics)
   - `logger.success()` - Positive milestones (successful refinement, 100% coverage)
   - `logger.warning()` - Potential issues (max iterations reached, refinement failures)
   - `logger.error()` - Actual errors (LLM failures, JSON parsing errors)

2. **Structured logging**:
   - Use keyword arguments for structured data: `logger.info("message", key=value)`
   - This allows log analysis tools to parse the data
   - Example: `logger.info("Gap detected", element_type="method", element_name="Execute")`

3. **Avoid log spam**:
   - Don't log every single gap in a loop at INFO level (use DEBUG)
   - Group similar logs with summaries
   - Use progress indicators for long operations

4. **Make logs actionable**:
   - Include context: file path, element name, iteration number
   - Show progress: "Iteration 2/3", "Coverage: 85.0% → 92.0%"
   - Use emojis sparingly for visual scanning: 🔄 (processing), ✓ (success), ❌ (failure), ⚠️ (warning)

### Testing the Logs

After implementing, test with:
```bash
# Run with verbose logging
python -m src.modules.docugen.workflows.parser_led.cli /path/to/test/project -v

# Expected log flow:
# 1. "Detected X gaps in file.cs" with breakdown
# 2. "Starting refinement iteration 1/3" 
# 3. For each gap: "🔄 Refining method 'X'" → "✓ Refined method 'X'"
# 4. "After iteration X: Y% coverage (Z gaps remaining)"
# 5. Either "🎉 Achieved 100% coverage" or "⚠️ Max iterations reached"
```

### Performance Considerations

- Debug logs won't impact performance unless `-v` flag is used
- Info logs are minimal and focused on milestones
- No log aggregation needed for this chore (future enhancement)

### Documentation Updates

After completing this chore, update:
- `docs/gap_detection_and_resolution.md` - Add section on "Observability and Logging" showing example log output
- Consider adding log samples to help users understand the refinement process
