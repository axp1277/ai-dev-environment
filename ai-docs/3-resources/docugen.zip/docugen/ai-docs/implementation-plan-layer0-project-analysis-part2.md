# Implementation Plan Part 2: Integration & Configuration

## 3. Integration with Existing Pipeline

### 3.1 Modified Orchestrator Flow

**File:** `src/modules/docugen/orchestrator.py` (modifications)

```python
class DocuGenOrchestrator:
    """Enhanced orchestrator with Layer 0 support"""
    
    def __init__(self, config: GraphConfig):
        self.config = config
        self.graph = self._build_graph()
        
        # NEW: Project context agent
        self.project_context_agent = None
        if config.enable_layer0:
            from .agents.project_context_agent import ProjectContextAgent
            self.project_context_agent = ProjectContextAgent(config)
    
    def process_directory(self, directory: Path, pattern: str = "*.cs") -> dict[Path, FileState]:
        """
        Process all C# files in a directory with optional Layer 0 context.
        """
        logger.info("Processing directory", directory=str(directory), pattern=pattern)
        
        # NEW: Run Layer 0 analysis first if enabled
        project_context = None
        if self.project_context_agent:
            logger.info("Running Layer 0: Project Context Analysis")
            try:
                project_context = self.project_context_agent.invoke(directory)
                logger.success(f"Layer 0 complete: {project_context.project_count} projects, "
                              f"{project_context.total_xaml_files} XAML files analyzed")
            except Exception as e:
                logger.warning(f"Layer 0 analysis failed (continuing without context): {e}")
        
        results = {}
        files = list(directory.rglob(pattern))
        
        logger.info(f"Found {len(files)} files to process")
        
        for file_path in files:
            logger.info(f"Processing file {len(results) + 1}/{len(files)} - {file_path}")
            try:
                # Process with Layer 0 context if available
                state = self.process_file(file_path, project_context)
                results[file_path] = state
            except Exception as e:
                logger.error(f"Failed to process file: {e}", file=str(file_path))
                results[file_path] = FileState(
                    file_path=file_path,
                    file_content="",
                    error_message=str(e),
                    flagged_for_review=True
                )
        
        return results
    
    def process_file(self, file_path: Path, project_context: Optional[ProjectContext] = None) -> FileState:
        """
        Process a single C# file with optional project context.
        """
        logger.info(f"Starting documentation pipeline - {file_path}")
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            logger.error(f"Failed to read file: {e}", file=str(file_path))
            raise
        
        # Initialize state with project context
        initial_state = FileState(
            file_path=file_path,
            file_content=content,
            project_context=project_context
        )
        
        # NEW: Enrich state with file-specific context from Layer 0
        if project_context:
            initial_state = self._enrich_file_state(initial_state, project_context)
        
        # Run the graph
        try:
            result = self.graph.invoke(initial_state)
            
            if isinstance(result, dict):
                final_state = FileState(**result)
            else:
                final_state = result
            
            if final_state.flagged_for_review:
                logger.warning(f"File flagged for manual review - {file_path}")
            else:
                logger.success(f"Documentation pipeline completed - {file_path}")
            
            return final_state
            
        except Exception as e:
            logger.exception(f"Pipeline execution failed: {e}", file=str(file_path))
            initial_state.error_message = f"Pipeline failed: {str(e)}"
            initial_state.flagged_for_review = True
            return initial_state
    
    def _enrich_file_state(self, state: FileState, context: ProjectContext) -> FileState:
        """
        Enrich file state with Layer 0 context.
        """
        file_path = state.file_path
        
        # Check if this is a code-behind file
        xaml_path = f"{file_path.parent / file_path.stem}.xaml"
        if xaml_path in context.xaml_code_behind_mapping.values():
            state.is_code_behind = True
            # Find the associated XAML
            for xaml, cs in context.xaml_code_behind_mapping.items():
                if cs == str(file_path):
                    state.associated_xaml = xaml
                    break
        
        # Determine parent project
        for csproj_analysis in context.csproj_analyses:
            csproj_path = Path(csproj_analysis.file_path)
            if file_path.is_relative_to(csproj_path.parent):
                state.parent_project = csproj_analysis.project_name
                state.used_nuget_packages = [
                    pkg.name for pkg in csproj_analysis.package_references
                ]
                break
        
        return state
```

---

## 4. Configuration Updates

### 4.1 config.yaml Extensions

**File:** `config.yaml`

```yaml
# DocuGen Configuration (with Layer 0 support)

# ... existing config ...

# Layer 0: Project Context Analysis (NEW)
# ----------------------------------------
layer0:
  enabled: true                          # Enable/disable Layer 0 analysis
  
  # .csproj analysis
  analyze_csproj: true                   # Analyze project files
  extract_dependencies: true             # Extract NuGet packages
  extract_project_refs: true             # Extract project-to-project references
  
  # XAML analysis
  analyze_xaml: true                     # Analyze XAML files (WPF/MAUI/UWP)
  extract_bindings: true                 # Extract data bindings
  extract_event_handlers: true           # Extract event handlers
  map_code_behind: true                  # Map XAML to code-behind files
  max_xaml_elements: 50                  # Limit UI elements per file (performance)
  
  # Context enhancement
  enrich_layer1: true                    # Provide context to file summarization
  enrich_layer2: true                    # Provide context to detailed documentation
  enrich_layer3: true                    # Provide context to relationship mapping
  enrich_layer4: true                    # Include in final documentation synthesis

# Processing options (updated)
processing:
  parallel_files: 1
  enable_incremental: true
  supported_languages:
    - "csharp"
  supported_project_files:               # NEW
    - "csproj"
  supported_ui_files:                    # NEW
    - "xaml"
```

### 4.2 GraphConfig Extensions

**File:** `src/modules/docugen/state.py`

```python
class GraphConfig(BaseModel):
    """Enhanced GraphConfig with Layer 0 support"""
    
    # ... existing fields ...
    
    # NEW: Layer 0 configuration
    enable_layer0: bool = True
    analyze_csproj: bool = True
    analyze_xaml: bool = True
    max_xaml_elements: int = 50
    enrich_layer1: bool = True
    enrich_layer2: bool = True
    enrich_layer3: bool = True
    enrich_layer4: bool = True
```

---

## 5. Prompt Engineering for Enhanced Layers

### 5.1 Enhanced Layer 1 Prompt

**File:** `src/modules/docugen/prompts/file_summarizer.md` (additions)

Add context section:

```markdown
# Additional Context (if available)

{{#if project_context}}
## Project Information
- **Project Name**: {{parent_project}}
- **Target Framework**: {{target_framework}}
- **Key Dependencies**: {{used_nuget_packages}}

{{#if is_code_behind}}
## UI Context
This file is code-behind for: **{{associated_xaml}}**

The associated XAML defines:
- UI Type: {{xaml_type}}
- Key UI Elements: {{xaml_elements}}
- Event Handlers: {{event_handlers}}

When summarizing, consider that this file primarily handles UI interactions and view logic.
{{/if}}

{{#if viewmodel_for}}
## ViewModel Context
This file appears to be a ViewModel bound to the following XAML files:
{{viewmodel_for}}

Focus on the data properties and commands exposed to the UI.
{{/if}}
{{/if}}
```

### 5.2 Enhanced Layer 3 Prompt

**File:** `src/modules/docugen/prompts/relationship_mapper.md` (additions)

```markdown
# Project-Level Context

{{#if project_context}}
## Solution Architecture
- Total Projects: {{project_count}}
- This file belongs to: **{{parent_project}}**

## Project Dependencies
The parent project {{parent_project}} depends on:
{{#each project_dependencies}}
- {{this}}
{{/each}}

## NuGet Packages Used
{{#each nuget_packages}}
- {{name}} ({{version}})
{{/each}}

## UI Architecture
{{#if ui_architecture}}
This project uses **{{ui_architecture}}** for its user interface.

{{#if xaml_relationships}}
### XAML-Code Relationships
{{#each xaml_relationships}}
- **{{xaml_file}}** ↔ **{{code_behind_file}}**
  - DataContext: {{data_context}}
  - Key Bindings: {{bindings}}
{{/each}}
{{/if}}
{{/if}}
{{/if}}
```

### 5.3 Enhanced Layer 4 Prompt

**File:** `src/modules/docugen/prompts/documentation_agent.md` (additions)

```markdown
# Layer 0: Project Context

You will receive project-wide context including:

## Project Metadata
- Solution structure (.csproj analysis)
- NuGet dependencies and versions
- Target frameworks and build configuration
- Project-to-project references

## UI Architecture (if applicable)
- XAML file structure
- UI navigation flow
- Data binding patterns (MVVM/MVC)
- ViewModel-View relationships

Your documentation should include:

1. **Project Overview** section covering:
   - Technology stack (frameworks, major packages)
   - Solution architecture (multi-project structure)
   - Target platforms and deployment

2. **UI Architecture** section (if XAML present) covering:
   - Application structure (Windows, Pages, UserControls)
   - Data binding patterns
   - Navigation flow
   - Key ViewModels and their responsibilities

3. Enhanced **Dependencies** section covering:
   - External NuGet packages with purposes
   - Internal project dependencies
   - Framework dependencies
```

---

## 6. Output Schema Updates

### 6.1 layer0_project_context.json

**New output file** generated alongside existing layer outputs:

```json
{
  "solution_name": "MyApp",
  "project_count": 3,
  "analysis_timestamp": "2025-10-22T16:45:00Z",
  
  "projects": [
    {
      "name": "MyApp.Core",
      "path": "./MyApp.Core/MyApp.Core.csproj",
      "target_frameworks": ["net8.0"],
      "output_type": "Library",
      "dependencies": {
        "nuget_packages": [
          {"name": "Newtonsoft.Json", "version": "13.0.3"},
          {"name": "EntityFrameworkCore", "version": "8.0.0"}
        ],
        "project_references": [
          {"name": "MyApp.Data", "path": "../MyApp.Data/MyApp.Data.csproj"}
        ],
        "framework_references": []
      }
    }
  ],
  
  "xaml_files": [
    {
      "file": "./Views/MainWindow.xaml",
      "type": "Window",
      "code_behind": "./Views/MainWindow.xaml.cs",
      "data_context": "MainViewModel",
      "bindings_count": 15,
      "event_handlers": ["SaveButton_Click", "CancelButton_Click"],
      "navigation_targets": []
    }
  ],
  
  "ui_architecture": "WPF",
  "technology_stack": {
    "frameworks": ["net8.0"],
    "ui_framework": "WPF",
    "major_packages": ["EntityFrameworkCore", "Newtonsoft.Json"],
    "patterns": ["MVVM"]
  },
  
  "dependency_graph": {
    "MyApp.UI": ["MyApp.Core", "MyApp.Data"],
    "MyApp.Core": ["MyApp.Data"],
    "MyApp.Data": []
  }
}
```

### 6.2 Enhanced DOCUMENTATION.md Structure

```markdown
# [Project Name] - Comprehensive Documentation

Generated: [timestamp]

---

## Table of Contents
1. Project Overview (NEW)
2. Technology Stack (NEW)
3. UI Architecture (NEW - if applicable)
4. File Summaries
5. Detailed Documentation
6. Relationships & Dependencies
7. Architecture Insights

---

## 1. Project Overview

**Project Type**: [Application/Library/Service]
**Target Frameworks**: .NET 8.0
**Projects**: 3
- MyApp.UI (WPF Application)
- MyApp.Core (Class Library)
- MyApp.Data (Data Access Layer)

### Solution Architecture

```
MyApp.UI (WPF)
├─> MyApp.Core
│   └─> MyApp.Data
└─> MyApp.Data
```

## 2. Technology Stack

### Frameworks
- .NET 8.0
- WPF (Windows Presentation Foundation)

### Major NuGet Packages
- **EntityFrameworkCore 8.0.0**: ORM for database access
- **Newtonsoft.Json 13.0.3**: JSON serialization
- **Prism.Wpf 8.1.97**: MVVM framework

### Build Configuration
- Language Version: C# 12
- Nullable: Enabled
- Output Type: WinExe

## 3. UI Architecture

**Pattern**: MVVM (Model-View-ViewModel)
**Total XAML Files**: 12

### Application Structure

#### Main Windows
- **MainWindow.xaml**: Primary application window
  - ViewModel: MainViewModel
  - Key Features: Dashboard, navigation menu
  - Navigation Targets: SettingsPage, DataGridPage

#### User Controls
- **CustomerEditControl.xaml**: Customer data entry
  - ViewModel: CustomerEditViewModel
  - Bindings: 23 data bindings
  - Commands: Save, Cancel, Delete

### Data Binding Patterns

Common ViewModel properties bound across multiple views:
- `IsLoading` (bound in 5 views)
- `StatusMessage` (bound in 8 views)
- `CurrentUser` (bound in 3 views)

### Navigation Flow

```
MainWindow
├─> SettingsPage
├─> DataGridPage
│   ├─> CustomerEditPage
│   └─> OrderDetailsPage
└─> ReportsPage
```

## 4. File Summaries
[existing content...]

## 5. Detailed Documentation
[existing content...]

## 6. Relationships & Dependencies

### Project Dependencies
[Enhanced with .csproj analysis]

### UI-Code Relationships
[NEW section showing XAML-ViewModel-Model connections]

## 7. Architecture Insights
[existing content...]
```

---

## 7. Testing Strategy

### 7.1 Unit Tests

**File:** `tests/unit/test_csproj_analyzer.py`

```python
"""Unit tests for .csproj analyzer"""

import pytest
from pathlib import Path
from src.modules.docugen.agents.csproj_analyzer_agent import CsprojAnalyzerAgent
from src.modules.docugen.state import GraphConfig


@pytest.fixture
def sample_csproj(tmp_path):
    """Create a sample .csproj file"""
    csproj_content = """
    <Project Sdk="Microsoft.NET.Sdk">
      <PropertyGroup>
        <TargetFramework>net8.0</TargetFramework>
        <OutputType>Library</OutputType>
        <RootNamespace>MyApp.Core</RootNamespace>
        <Nullable>enable</Nullable>
      </PropertyGroup>
      
      <ItemGroup>
        <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
        <PackageReference Include="EntityFrameworkCore" Version="8.0.0" />
      </ItemGroup>
      
      <ItemGroup>
        <ProjectReference Include="../MyApp.Data/MyApp.Data.csproj" />
      </ItemGroup>
    </Project>
    """
    
    csproj_path = tmp_path / "test.csproj"
    csproj_path.write_text(csproj_content)
    return csproj_path


def test_csproj_basic_analysis(sample_csproj):
    """Test basic .csproj parsing"""
    config = GraphConfig()
    agent = CsprojAnalyzerAgent(config)
    
    result = agent.invoke(sample_csproj)
    
    assert result.project_name == "test"
    assert result.target_frameworks == ["net8.0"]
    assert result.output_type == "Library"
    assert result.root_namespace == "MyApp.Core"
    assert result.nullable == "enable"


def test_csproj_package_extraction(sample_csproj):
    """Test NuGet package extraction"""
    config = GraphConfig()
    agent = CsprojAnalyzerAgent(config)
    
    result = agent.invoke(sample_csproj)
    
    assert len(result.package_references) == 2
    package_names = [pkg.name for pkg in result.package_references]
    assert "Newtonsoft.Json" in package_names
    assert "EntityFrameworkCore" in package_names
    
    # Check version extraction
    json_pkg = next(p for p in result.package_references if p.name == "Newtonsoft.Json")
    assert json_pkg.version == "13.0.3"


def test_csproj_project_references(sample_csproj):
    """Test project reference extraction"""
    config = GraphConfig()
    agent = CsprojAnalyzerAgent(config)
    
    result = agent.invoke(sample_csproj)
    
    assert len(result.project_references) == 1
    assert result.project_references[0].name == "MyApp.Data"
```

**File:** `tests/unit/test_xaml_analyzer.py`

```python
"""Unit tests for XAML analyzer"""

import pytest
from pathlib import Path
from src.modules.docugen.agents.xaml_analyzer_agent import XamlAnalyzerAgent
from src.modules.docugen.state import GraphConfig


@pytest.fixture
def sample_xaml(tmp_path):
    """Create a sample XAML file"""
    xaml_content = """
    <Window x:Class="MyApp.Views.MainWindow"
            xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
            xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
            Title="Main Window" Height="450" Width="800">
        <Grid>
            <Button x:Name="SaveButton" Content="Save" Click="SaveButton_Click"/>
            <TextBox x:Name="NameTextBox" Text="{Binding CustomerName, Mode=TwoWay}"/>
        </Grid>
    </Window>
    """
    
    xaml_path = tmp_path / "MainWindow.xaml"
    xaml_path.write_text(xaml_content)
    
    # Create code-behind
    cs_path = tmp_path / "MainWindow.xaml.cs"
    cs_path.write_text("// code-behind")
    
    return xaml_path


def test_xaml_basic_analysis(sample_xaml):
    """Test basic XAML parsing"""
    config = GraphConfig()
    agent = XamlAnalyzerAgent(config)
    
    result = agent.invoke(sample_xaml)
    
    assert result.xaml_type == "Window"
    assert result.root_element == "Window"
    assert result.class_name == "MyApp.Views.MainWindow"
    assert result.code_behind_file is not None


def test_xaml_element_extraction(sample_xaml):
    """Test UI element extraction"""
    config = GraphConfig()
    agent = XamlAnalyzerAgent(config)
    
    result = agent.invoke(sample_xaml)
    
    assert len(result.named_elements) == 2
    assert "SaveButton" in result.named_elements
    assert "NameTextBox" in result.named_elements
    assert result.named_elements["SaveButton"] == "Button"


def test_xaml_binding_extraction(sample_xaml):
    """Test data binding extraction"""
    config = GraphConfig()
    agent = XamlAnalyzerAgent(config)
    
    result = agent.invoke(sample_xaml)
    
    assert len(result.data_bindings) >= 1
    name_binding = next((b for b in result.data_bindings if b.path == "CustomerName"), None)
    assert name_binding is not None
    assert name_binding.mode == "TwoWay"


def test_xaml_event_handler_extraction(sample_xaml):
    """Test event handler extraction"""
    config = GraphConfig()
    agent = XamlAnalyzerAgent(config)
    
    result = agent.invoke(sample_xaml)
    
    assert len(result.event_handlers) >= 1
    click_handler = next((h for h in result.event_handlers if h.event == "Click"), None)
    assert click_handler is not None
    assert click_handler.handler_name == "SaveButton_Click"
```

---

## 8. Implementation Phases

### Phase 1: Foundation (Week 1)
- [ ] Implement state schema extensions
- [ ] Create CsprojAnalyzerAgent
- [ ] Create XamlAnalyzerAgent  
- [ ] Add unit tests for both agents
- [ ] Update GraphConfig

### Phase 2: Integration (Week 1-2)
- [ ] Create ProjectContextAgent orchestrator
- [ ] Integrate Layer 0 into main orchestrator
- [ ] Update config.yaml schema
- [ ] Implement file state enrichment logic

### Phase 3: Enhancement (Week 2)
- [ ] Update Layer 1 prompts with context
- [ ] Update Layer 2 prompts with UI context
- [ ] Update Layer 3 prompts with project dependencies
- [ ] Update Layer 4 prompt for comprehensive synthesis

### Phase 4: Output & CLI (Week 2-3)
- [ ] Implement layer0_project_context.json output
- [ ] Update DocumentationAgent for enhanced output
- [ ] Add CLI flags for Layer 0 control
- [ ] Update help documentation

### Phase 5: Testing & Validation (Week 3)
- [ ] End-to-end testing with sample WPF projects
- [ ] Validation of XAML analysis accuracy
- [ ] Validation of .csproj parsing
- [ ] Performance testing with large solutions

### Phase 6: Documentation & Polish (Week 3)
- [ ] Update README with Layer 0 features
- [ ] Create migration guide for existing users
- [ ] Add example configurations
- [ ] Performance optimization

---

## 9. Migration Path for Existing Users

### Backwards Compatibility

Layer 0 is **opt-in by default** but enabled in new configurations:

```yaml
layer0:
  enabled: true  # Set to false to disable
```

### Migration Steps

1. **Existing users**: No changes required. Layer 0 will be disabled by default for existing config.yaml files.

2. **New users**: Layer 0 enabled by default in config.example.yaml.

3. **Opt-in**: Add the `layer0` section to enable:
   ```yaml
   layer0:
     enabled: true
     analyze_csproj: true
     analyze_xaml: true
   ```

4. **Gradual adoption**: Users can enable individual features:
   ```yaml
   layer0:
     enabled: true
     analyze_csproj: true
     analyze_xaml: false  # Skip XAML initially
   ```

---

## 10. Performance Considerations

### Optimization Strategies

1. **Caching**: Cache .csproj and XAML analysis results
   ```python
   # Implement caching for repeat runs
   @lru_cache(maxsize=100)
   def analyze_csproj(path: str) -> CsprojAnalysis:
       ...
   ```

2. **Parallel processing**: Analyze .csproj and XAML files in parallel
   ```python
   with ThreadPoolExecutor(max_workers=4) as executor:
       csproj_futures = [executor.submit(analyze_csproj, f) for f in csproj_files]
       xaml_futures = [executor.submit(analyze_xaml, f) for f in xaml_files]
   ```

3. **Lazy loading**: Only load XAML details when referenced
4. **Size limits**: Limit XAML element extraction (configurable)

### Expected Performance Impact

- **Small projects** (1-3 .csproj, <10 XAML): +5-10 seconds
- **Medium projects** (4-10 .csproj, 10-50 XAML): +20-30 seconds
- **Large solutions** (10+ .csproj, 50+ XAML): +1-2 minutes

This is a one-time cost at the start of documentation generation.

---

## 11. Success Metrics

### Quality Metrics
- [ ] 100% accurate .csproj parsing for modern SDK-style projects
- [ ] 95%+ accurate XAML binding extraction
- [ ] 90%+ accurate code-behind mapping
- [ ] Zero breaking changes to existing pipeline

### Documentation Enhancement
- [ ] Project overview section present in all outputs
- [ ] UI architecture section for WPF/MAUI projects
- [ ] Dependency graph visualization
- [ ] ViewMod el-View relationship mapping

### User Adoption
- [ ] Positive feedback from 5+ users
- [ ] <10% performance regression
- [ ] Clear documentation and examples

---

## 12. Future Enhancements

### Post-MVP Features

1. **Solution file (.sln) parsing**
   - Multi-project dependency visualization
   - Build order determination

2. **Resource file analysis**
   - .resx file parsing
   - Localization coverage

3. **Config file analysis**
   - app.config / web.config
   - appsettings.json

4. **Test project detection**
   - Identify unit test projects
   - Map tests to source code

5. **LLM-powered insights**
   - Use LLM to analyze dependency patterns
   - Suggest architectural improvements
   - Identify potential technical debt

---

## Appendix: Example Outputs

### Example 1: WPF MVVM Application

**layer0_project_context.json** (excerpt):
```json
{
  "ui_architecture": "WPF",
  "technology_stack": {
    "frameworks": ["net8.0"],
    "ui_framework": "WPF",
    "major_packages": ["Prism.Wpf", "MaterialDesignThemes"],
    "patterns": ["MVVM"]
  },
  "viewmodel_bindings": {
    "MainViewModel": ["MainWindow.xaml", "DashboardView.xaml"],
    "CustomerViewModel": ["CustomerEditView.xaml"]
  }
}
```

**DOCUMENTATION.md** (excerpt):
```markdown
## UI Architecture

This WPF application follows the MVVM (Model-View-ViewModel) pattern using Prism framework.

### ViewModels and Their Views

#### MainViewModel
**Bound to**: MainWindow.xaml, DashboardView.xaml

**Key Properties**:
- `CurrentUser` (string): Bound to username display
- `NavigateCommand` (ICommand): Handles menu navigation
- `IsLoading` (bool): Controls loading indicator

**Data Bindings**:
- MainWindow.xaml: 12 bindings
- DashboardView.xaml: 8 bindings
```

---

## Conclusion

This implementation plan provides a comprehensive roadmap for adding Layer 0 (Project Context Analysis) to docugen. The phased approach ensures:

1. **Minimal disruption** to existing users
2. **Significant value** for WPF/MAUI projects
3. **Extensible architecture** for future enhancements
4. **Clear migration path** and documentation

**Next Steps**: Review this plan, get approval, and begin Phase 1 implementation.
