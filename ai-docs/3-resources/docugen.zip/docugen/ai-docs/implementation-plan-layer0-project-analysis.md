# Implementation Plan: Layer 0 - Project Analysis (XAML & .csproj)

## Executive Summary

This document outlines the implementation plan for adding **Layer 0 - Project Context Analysis** to the docugen pipeline. This new layer will analyze `.csproj` and `.xaml` files to provide project-wide context that enriches all subsequent documentation layers.

**Timeline Estimate:** 2-3 weeks  
**Priority:** High (significantly enhances documentation quality)  
**Complexity:** Medium (requires XML parsing, new agent patterns)

---

## 1. Architecture Overview

### Current Architecture (Layers 1-4)
```
Input: C# Files (.cs)
↓
Layer 1: File Summarization
↓
Layer 2: Detailed Documentation
↓
Layer 3: Relationship Mapping
↓
Layer 4: Documentation Synthesis
↓
Output: DOCUMENTATION.md + JSON files
```

### New Architecture (Layer 0 + Layers 1-4)
```
Input: .csproj, .xaml, .cs files
↓
Layer 0: Project Analysis (NEW)
├── .csproj Analyzer → Project metadata, dependencies, build config
├── XAML Analyzer → UI structure, bindings, navigation
└── Solution Context → Multi-project relationships
↓ (provides context to)
Layer 1: File Summarization (enhanced with project context)
↓
Layer 2: Detailed Documentation (enhanced with UI/dependency mapping)
↓
Layer 3: Relationship Mapping (enhanced with project-level relationships)
↓
Layer 4: Documentation Synthesis (includes project overview, UI architecture)
↓
Output: Enhanced DOCUMENTATION.md + layer0_project_context.json
```

---

## 2. Component Design

### 2.1 New State Schema Extensions

**File:** `src/modules/docugen/state.py`

```python
from typing import Optional, List, Dict
from pydantic import BaseModel, Field

# === .csproj Analysis Models ===

class PackageDependency(BaseModel):
    """NuGet package dependency"""
    name: str
    version: str
    target_framework: Optional[str] = None

class ProjectReference(BaseModel):
    """Reference to another project in the solution"""
    name: str
    path: str
    relative_path: str

class BuildProperty(BaseModel):
    """Build configuration property"""
    name: str
    value: str
    condition: Optional[str] = None

class CsprojAnalysis(BaseModel):
    """Complete .csproj file analysis"""
    file_path: str
    project_name: str
    target_frameworks: List[str]  # e.g., ["net8.0", "net6.0"]
    output_type: str  # Library, Exe, WinExe
    root_namespace: Optional[str] = None
    assembly_name: Optional[str] = None
    
    # Dependencies
    package_references: List[PackageDependency] = Field(default_factory=list)
    project_references: List[ProjectReference] = Field(default_factory=list)
    framework_references: List[str] = Field(default_factory=list)  # e.g., ["Microsoft.WindowsDesktop.App.WPF"]
    
    # Build configuration
    build_properties: Dict[str, str] = Field(default_factory=dict)
    conditional_compilation_symbols: List[str] = Field(default_factory=list)
    
    # Resources
    embedded_resources: List[str] = Field(default_factory=list)
    content_files: List[str] = Field(default_factory=list)
    
    # Metadata
    sdk: str = "Microsoft.NET.Sdk"  # SDK type
    language_version: Optional[str] = None
    nullable: Optional[str] = None


# === XAML Analysis Models ===

class XamlBinding(BaseModel):
    """Data binding in XAML"""
    element_name: Optional[str] = None
    property: str
    path: str
    mode: Optional[str] = None  # OneWay, TwoWay, OneTime
    converter: Optional[str] = None
    source: Optional[str] = None

class XamlEventHandler(BaseModel):
    """Event handler defined in XAML"""
    element_name: Optional[str] = None
    element_type: str
    event: str
    handler_name: str

class XamlResource(BaseModel):
    """Resource dictionary reference"""
    source: str
    merge_type: str  # "MergedDictionary" or "Static"

class XamlElement(BaseModel):
    """UI element in XAML"""
    type: str  # Button, TextBox, Grid, etc.
    name: Optional[str] = None
    properties: Dict[str, str] = Field(default_factory=dict)
    children_count: int = 0

class XamlAnalysis(BaseModel):
    """Complete XAML file analysis"""
    file_path: str
    xaml_type: str  # Window, UserControl, Page, ResourceDictionary
    root_element: str
    
    # Code-behind connection
    code_behind_file: Optional[str] = None
    class_name: Optional[str] = None
    namespace: Optional[str] = None
    
    # Data context
    data_context_type: Optional[str] = None  # ViewModel name
    data_context_binding: Optional[str] = None
    
    # UI structure
    ui_elements: List[XamlElement] = Field(default_factory=list)
    named_elements: Dict[str, str] = Field(default_factory=dict)  # name -> type
    
    # Bindings and events
    data_bindings: List[XamlBinding] = Field(default_factory=list)
    event_handlers: List[XamlEventHandler] = Field(default_factory=list)
    
    # Resources
    resources: List[XamlResource] = Field(default_factory=list)
    styles: List[str] = Field(default_factory=list)
    
    # Navigation
    navigation_targets: List[str] = Field(default_factory=list)  # For Pages/Windows


# === Layer 0 State ===

class ProjectContext(BaseModel):
    """Layer 0: Project-wide context analysis"""
    
    # Project files
    csproj_analyses: List[CsprojAnalysis] = Field(default_factory=list)
    xaml_analyses: List[XamlAnalysis] = Field(default_factory=list)
    
    # Solution-level metadata
    solution_name: Optional[str] = None
    project_count: int = 0
    
    # Aggregated insights
    all_dependencies: Dict[str, str] = Field(default_factory=dict)  # package -> version
    project_dependency_graph: Dict[str, List[str]] = Field(default_factory=dict)  # project -> depends on
    common_frameworks: List[str] = Field(default_factory=list)
    
    # UI insights (from XAML)
    ui_architecture: Optional[str] = None  # "WPF", "MAUI", "UWP", "None"
    total_xaml_files: int = 0
    xaml_code_behind_mapping: Dict[str, str] = Field(default_factory=dict)  # .xaml -> .xaml.cs
    viewmodel_bindings: Dict[str, List[str]] = Field(default_factory=dict)  # ViewModel -> [XAML files]


# === Extended FileState ===

class FileState(BaseModel):
    """Enhanced FileState with Layer 0 context"""
    
    # ... (existing fields remain) ...
    
    # NEW: Layer 0 context reference
    project_context: Optional[ProjectContext] = None
    
    # NEW: File-specific context from Layer 0
    is_code_behind: bool = False
    associated_xaml: Optional[str] = None  # If this .cs is code-behind
    used_nuget_packages: List[str] = Field(default_factory=list)
    parent_project: Optional[str] = None


# === Validation Models for Layer 0 ===

class Layer0ValidationResult(BaseModel):
    """Validation result for Layer 0 project analysis"""
    passed: bool
    issues: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    
    # Specific checks
    has_valid_csproj: bool = True
    has_consistent_frameworks: bool = True
    has_missing_dependencies: List[str] = Field(default_factory=list)
```

---

### 2.2 New Agents

#### 2.2.1 CsprojAnalyzerAgent

**File:** `src/modules/docugen/agents/csproj_analyzer_agent.py`

```python
"""
.csproj Analyzer Agent

Analyzes C# project files to extract:
- Project metadata (name, framework, SDK)
- NuGet dependencies
- Project references
- Build configuration
- Resources and assets
"""

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List, Dict, Optional
from loguru import logger

from ..state import (
    CsprojAnalysis, PackageDependency, ProjectReference,
    GraphConfig
)


class CsprojAnalyzerAgent:
    """Agent for analyzing .csproj files"""
    
    def __init__(self, config: GraphConfig):
        self.config = config
        logger.info("CsprojAnalyzerAgent initialized")
    
    def invoke(self, csproj_path: Path) -> CsprojAnalysis:
        """
        Analyze a .csproj file.
        
        Args:
            csproj_path: Path to the .csproj file
            
        Returns:
            CsprojAnalysis with extracted metadata
        """
        logger.info(f"Analyzing .csproj file: {csproj_path}")
        
        try:
            # Parse XML
            tree = ET.parse(csproj_path)
            root = tree.getroot()
            
            # Extract basic project info
            project_name = csproj_path.stem
            
            # Target frameworks
            target_frameworks = self._extract_target_frameworks(root)
            
            # Output type
            output_type = self._extract_output_type(root)
            
            # SDK
            sdk = root.get('Sdk', 'Microsoft.NET.Sdk')
            
            # Root namespace and assembly name
            root_namespace = self._extract_property(root, 'RootNamespace')
            assembly_name = self._extract_property(root, 'AssemblyName')
            
            # Dependencies
            package_refs = self._extract_package_references(root)
            project_refs = self._extract_project_references(root, csproj_path)
            framework_refs = self._extract_framework_references(root)
            
            # Build properties
            build_props = self._extract_build_properties(root)
            
            # Compilation symbols
            comp_symbols = self._extract_compilation_symbols(root)
            
            # Resources
            embedded_resources = self._extract_embedded_resources(root)
            content_files = self._extract_content_files(root)
            
            # Language features
            lang_version = self._extract_property(root, 'LangVersion')
            nullable = self._extract_property(root, 'Nullable')
            
            analysis = CsprojAnalysis(
                file_path=str(csproj_path),
                project_name=project_name,
                target_frameworks=target_frameworks,
                output_type=output_type,
                root_namespace=root_namespace,
                assembly_name=assembly_name or project_name,
                package_references=package_refs,
                project_references=project_refs,
                framework_references=framework_refs,
                build_properties=build_props,
                conditional_compilation_symbols=comp_symbols,
                embedded_resources=embedded_resources,
                content_files=content_files,
                sdk=sdk,
                language_version=lang_version,
                nullable=nullable
            )
            
            logger.success(f"Successfully analyzed {csproj_path.name}")
            return analysis
            
        except Exception as e:
            logger.error(f"Failed to analyze {csproj_path}: {e}")
            raise
    
    def _extract_target_frameworks(self, root) -> List[str]:
        """Extract target framework(s)"""
        # Check for single framework
        tf_elem = root.find(".//TargetFramework")
        if tf_elem is not None and tf_elem.text:
            return [tf_elem.text.strip()]
        
        # Check for multiple frameworks
        tfs_elem = root.find(".//TargetFrameworks")
        if tfs_elem is not None and tfs_elem.text:
            return [f.strip() for f in tfs_elem.text.split(';')]
        
        return []
    
    def _extract_output_type(self, root) -> str:
        """Extract output type (Library, Exe, WinExe)"""
        elem = root.find(".//OutputType")
        return elem.text if elem is not None and elem.text else "Library"
    
    def _extract_property(self, root, property_name: str) -> Optional[str]:
        """Extract a single property value"""
        elem = root.find(f".//{property_name}")
        return elem.text.strip() if elem is not None and elem.text else None
    
    def _extract_package_references(self, root) -> List[PackageDependency]:
        """Extract NuGet package references"""
        packages = []
        for pkg in root.findall(".//PackageReference"):
            name = pkg.get('Include')
            version = pkg.get('Version')
            
            if not version:
                # Check for Version as child element
                version_elem = pkg.find('Version')
                version = version_elem.text if version_elem is not None else None
            
            if name:
                packages.append(PackageDependency(
                    name=name,
                    version=version or "Unknown"
                ))
        
        return packages
    
    def _extract_project_references(self, root, csproj_path: Path) -> List[ProjectReference]:
        """Extract project-to-project references"""
        projects = []
        for proj in root.findall(".//ProjectReference"):
            include = proj.get('Include')
            if include:
                ref_path = (csproj_path.parent / include).resolve()
                projects.append(ProjectReference(
                    name=Path(include).stem,
                    path=str(ref_path),
                    relative_path=include
                ))
        
        return projects
    
    def _extract_framework_references(self, root) -> List[str]:
        """Extract framework references"""
        frameworks = []
        for fw in root.findall(".//FrameworkReference"):
            include = fw.get('Include')
            if include:
                frameworks.append(include)
        
        return frameworks
    
    def _extract_build_properties(self, root) -> Dict[str, str]:
        """Extract build configuration properties"""
        properties = {}
        
        # Common properties to extract
        prop_names = [
            'Configuration', 'Platform', 'PlatformTarget',
            'AllowUnsafeBlocks', 'TreatWarningsAsErrors',
            'GenerateDocumentationFile', 'NoWarn'
        ]
        
        for prop_name in prop_names:
            value = self._extract_property(root, prop_name)
            if value:
                properties[prop_name] = value
        
        return properties
    
    def _extract_compilation_symbols(self, root) -> List[str]:
        """Extract conditional compilation symbols"""
        elem = root.find(".//DefineConstants")
        if elem is not None and elem.text:
            return [s.strip() for s in elem.text.split(';') if s.strip()]
        return []
    
    def _extract_embedded_resources(self, root) -> List[str]:
        """Extract embedded resource files"""
        resources = []
        for res in root.findall(".//EmbeddedResource"):
            include = res.get('Include')
            if include:
                resources.append(include)
        return resources
    
    def _extract_content_files(self, root) -> List[str]:
        """Extract content files"""
        content = []
        for item in root.findall(".//Content"):
            include = item.get('Include')
            if include:
                content.append(include)
        return content


def analyze_csproj(csproj_path: Path, config: GraphConfig) -> CsprojAnalysis:
    """
    Convenience function to analyze a .csproj file.
    
    Args:
        csproj_path: Path to .csproj file
        config: Graph configuration
        
    Returns:
        CsprojAnalysis result
    """
    agent = CsprojAnalyzerAgent(config)
    return agent.invoke(csproj_path)
```

#### 2.2.2 XamlAnalyzerAgent

**File:** `src/modules/docugen/agents/xaml_analyzer_agent.py`

```python
"""
XAML Analyzer Agent

Analyzes XAML files to extract:
- UI structure and elements
- Data bindings
- Event handlers
- Resource references
- Code-behind connections
"""

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List, Dict, Optional
from loguru import logger

from ..state import (
    XamlAnalysis, XamlBinding, XamlEventHandler,
    XamlResource, XamlElement, GraphConfig
)


class XamlAnalyzerAgent:
    """Agent for analyzing XAML files"""
    
    # Common XAML namespaces
    NAMESPACES = {
        'x': 'http://schemas.microsoft.com/winfx/2006/xaml',
        'd': 'http://schemas.microsoft.com/expression/blend/2008',
        'mc': 'http://schemas.openxmlformats.org/markup-compatibility/2006',
        'wpf': 'http://schemas.microsoft.com/winfx/2006/xaml/presentation',
    }
    
    def __init__(self, config: GraphConfig):
        self.config = config
        logger.info("XamlAnalyzerAgent initialized")
    
    def invoke(self, xaml_path: Path) -> XamlAnalysis:
        """
        Analyze a XAML file.
        
        Args:
            xaml_path: Path to the XAML file
            
        Returns:
            XamlAnalysis with extracted UI structure
        """
        logger.info(f"Analyzing XAML file: {xaml_path}")
        
        try:
            # Parse XML
            tree = ET.parse(xaml_path)
            root = tree.getroot()
            
            # Determine XAML type from root element
            xaml_type = self._determine_xaml_type(root)
            root_element = root.tag.split('}')[-1]  # Remove namespace
            
            # Extract class and namespace
            class_name = root.get(f"{{{self.NAMESPACES['x']}}}Class")
            namespace = None
            if class_name and '.' in class_name:
                namespace = '.'.join(class_name.split('.')[:-1])
            
            # Code-behind file
            code_behind = self._find_code_behind(xaml_path)
            
            # DataContext
            data_context_type, data_context_binding = self._extract_data_context(root)
            
            # UI elements
            ui_elements = self._extract_ui_elements(root)
            named_elements = self._extract_named_elements(root)
            
            # Bindings
            data_bindings = self._extract_data_bindings(root)
            
            # Event handlers
            event_handlers = self._extract_event_handlers(root)
            
            # Resources
            resources = self._extract_resources(root)
            styles = self._extract_styles(root)
            
            # Navigation (for Pages/Windows)
            navigation_targets = self._extract_navigation_targets(root)
            
            analysis = XamlAnalysis(
                file_path=str(xaml_path),
                xaml_type=xaml_type,
                root_element=root_element,
                code_behind_file=code_behind,
                class_name=class_name,
                namespace=namespace,
                data_context_type=data_context_type,
                data_context_binding=data_context_binding,
                ui_elements=ui_elements,
                named_elements=named_elements,
                data_bindings=data_bindings,
                event_handlers=event_handlers,
                resources=resources,
                styles=styles,
                navigation_targets=navigation_targets
            )
            
            logger.success(f"Successfully analyzed {xaml_path.name}")
            return analysis
            
        except Exception as e:
            logger.error(f"Failed to analyze {xaml_path}: {e}")
            raise
    
    def _determine_xaml_type(self, root) -> str:
        """Determine XAML file type from root element"""
        tag = root.tag.split('}')[-1]
        
        type_map = {
            'Window': 'Window',
            'UserControl': 'UserControl',
            'Page': 'Page',
            'ResourceDictionary': 'ResourceDictionary',
            'Application': 'Application',
        }
        
        return type_map.get(tag, 'Unknown')
    
    def _find_code_behind(self, xaml_path: Path) -> Optional[str]:
        """Find associated code-behind file"""
        # Common patterns: .xaml.cs, .xaml.vb
        cs_file = xaml_path.parent / f"{xaml_path.name}.cs"
        if cs_file.exists():
            return str(cs_file)
        
        vb_file = xaml_path.parent / f"{xaml_path.name}.vb"
        if vb_file.exists():
            return str(vb_file)
        
        return None
    
    def _extract_data_context(self, root) -> tuple[Optional[str], Optional[str]]:
        """Extract DataContext information"""
        # Check for DataContext attribute
        dc_attr = root.get('DataContext')
        if dc_attr:
            return (dc_attr, None)
        
        # Check for DataContext element (binding syntax)
        # This is simplified - full implementation would parse binding syntax
        return (None, None)
    
    def _extract_ui_elements(self, root, max_elements: int = 50) -> List[XamlElement]:
        """Extract UI elements (limited to prevent huge lists)"""
        elements = []
        
        def traverse(elem, depth=0):
            if len(elements) >= max_elements or depth > 10:
                return
            
            tag = elem.tag.split('}')[-1]
            name = elem.get(f"{{{self.NAMESPACES['x']}}}Name")
            
            # Extract some key properties
            properties = {}
            for key, value in elem.attrib.items():
                clean_key = key.split('}')[-1]
                if clean_key not in ['Name', 'Class']:
                    properties[clean_key] = value[:100]  # Limit length
            
            children_count = len(list(elem))
            
            elements.append(XamlElement(
                type=tag,
                name=name,
                properties=properties,
                children_count=children_count
            ))
            
            # Recurse into children
            for child in elem:
                traverse(child, depth + 1)
        
        traverse(root)
        return elements[:max_elements]
    
    def _extract_named_elements(self, root) -> Dict[str, str]:
        """Extract named elements (x:Name)"""
        named = {}
        
        def traverse(elem):
            name = elem.get(f"{{{self.NAMESPACES['x']}}}Name")
            if name:
                tag = elem.tag.split('}')[-1]
                named[name] = tag
            
            for child in elem:
                traverse(child)
        
        traverse(root)
        return named
    
    def _extract_data_bindings(self, root) -> List[XamlBinding]:
        """Extract data bindings (simplified)"""
        bindings = []
        
        def traverse(elem):
            elem_name = elem.get(f"{{{self.NAMESPACES['x']}}}Name")
            
            for key, value in elem.attrib.items():
                # Look for binding syntax: {Binding ...}
                if '{Binding' in str(value):
                    clean_key = key.split('}')[-1]
                    
                    # Parse binding (simplified)
                    path = self._parse_binding_path(value)
                    mode = self._parse_binding_mode(value)
                    
                    if path:
                        bindings.append(XamlBinding(
                            element_name=elem_name,
                            property=clean_key,
                            path=path,
                            mode=mode
                        ))
            
            for child in elem:
                traverse(child)
        
        traverse(root)
        return bindings
    
    def _parse_binding_path(self, binding_str: str) -> Optional[str]:
        """Extract path from binding string"""
        # Simplified parser
        if 'Path=' in binding_str:
            parts = binding_str.split('Path=')
            if len(parts) > 1:
                path = parts[1].split(',')[0].split('}')[0].strip()
                return path
        
        # Default binding format: {Binding PropertyName}
        parts = binding_str.replace('{Binding', '').replace('}', '').strip().split(',')
        if parts and parts[0].strip():
            return parts[0].strip()
        
        return None
    
    def _parse_binding_mode(self, binding_str: str) -> Optional[str]:
        """Extract mode from binding string"""
        if 'Mode=' in binding_str:
            parts = binding_str.split('Mode=')
            if len(parts) > 1:
                mode = parts[1].split(',')[0].split('}')[0].strip()
                return mode
        return None
    
    def _extract_event_handlers(self, root) -> List[XamlEventHandler]:
        """Extract event handlers"""
        handlers = []
        
        # Common events to look for
        common_events = ['Click', 'Loaded', 'SelectionChanged', 'TextChanged', 'PreviewMouseDown']
        
        def traverse(elem):
            elem_name = elem.get(f"{{{self.NAMESPACES['x']}}}Name")
            elem_type = elem.tag.split('}')[-1]
            
            for event in common_events:
                handler = elem.get(event)
                if handler:
                    handlers.append(XamlEventHandler(
                        element_name=elem_name,
                        element_type=elem_type,
                        event=event,
                        handler_name=handler
                    ))
            
            for child in elem:
                traverse(child)
        
        traverse(root)
        return handlers
    
    def _extract_resources(self, root) -> List[XamlResource]:
        """Extract resource dictionary references"""
        resources = []
        
        # Find ResourceDictionary elements
        for rd in root.findall(".//*ResourceDictionary"):
            for merged in rd.findall(".//*MergedDictionary"):
                source = merged.get('Source')
                if source:
                    resources.append(XamlResource(
                        source=source,
                        merge_type="MergedDictionary"
                    ))
        
        return resources
    
    def _extract_styles(self, root) -> List[str]:
        """Extract style references"""
        styles = []
        
        def traverse(elem):
            style = elem.get('Style')
            if style and 'StaticResource' in style:
                # Extract resource key
                key = style.replace('{StaticResource', '').replace('}', '').strip()
                if key not in styles:
                    styles.append(key)
            
            for child in elem:
                traverse(child)
        
        traverse(root)
        return styles
    
    def _extract_navigation_targets(self, root) -> List[str]:
        """Extract navigation targets (for Frame navigation)"""
        targets = []
        
        # Look for NavigationService.Navigate or Frame.Source
        def traverse(elem):
            for key, value in elem.attrib.items():
                if 'Navigate' in key or 'Source' in key:
                    if '.xaml' in str(value).lower():
                        targets.append(str(value))
            
            for child in elem:
                traverse(child)
        
        traverse(root)
        return targets


def analyze_xaml(xaml_path: Path, config: GraphConfig) -> XamlAnalysis:
    """
    Convenience function to analyze a XAML file.
    
    Args:
        xaml_path: Path to XAML file
        config: Graph configuration
        
    Returns:
        XamlAnalysis result
    """
    agent = XamlAnalyzerAgent(config)
    return agent.invoke(xaml_path)
```

#### 2.2.3 ProjectContextAgent

**File:** `src/modules/docugen/agents/project_context_agent.py`

```python
"""
Project Context Agent (Layer 0 Orchestrator)

Coordinates .csproj and XAML analysis to build project-wide context.
"""

from pathlib import Path
from typing import List, Dict
from loguru import logger

from ..state import ProjectContext, GraphConfig
from .csproj_analyzer_agent import CsprojAnalyzerAgent
from .xaml_analyzer_agent import XamlAnalyzerAgent


class ProjectContextAgent:
    """
    Layer 0 orchestrator - builds project-wide context.
    """
    
    def __init__(self, config: GraphConfig):
        self.config = config
        self.csproj_analyzer = CsprojAnalyzerAgent(config)
        self.xaml_analyzer = XamlAnalyzerAgent(config)
        logger.info("ProjectContextAgent initialized")
    
    def invoke(self, project_dir: Path) -> ProjectContext:
        """
        Analyze all .csproj and .xaml files in a project directory.
        
        Args:
            project_dir: Root directory of the project
            
        Returns:
            ProjectContext with aggregated analysis
        """
        logger.info(f"Building project context for: {project_dir}")
        
        # Find all .csproj files
        csproj_files = list(project_dir.rglob("*.csproj"))
        logger.info(f"Found {len(csproj_files)} .csproj files")
        
        # Find all .xaml files
        xaml_files = list(project_dir.rglob("*.xaml"))
        logger.info(f"Found {len(xaml_files)} XAML files")
        
        # Analyze .csproj files
        csproj_analyses = []
        for csproj in csproj_files:
            try:
                analysis =
