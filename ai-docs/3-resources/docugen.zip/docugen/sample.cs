
using System;
using System.Collections.Generic;

namespace DataLayer
{
    public interface IRepository<T>
    {
        T GetById(int id);
        IEnumerable<T> GetAll();
        void Add(T entity);
        void Delete(int id);
    }
    
    public class UserRepository : IRepository<User>
    {
        private readonly DbContext context;
        private List<User> cache;
        
        public UserRepository(DbContext context)
        {
            this.context = context;
            cache = new List<User>();
        }
        
        public User GetById(int id)
        {
            return context.Users.Find(id);
        }
        
        public IEnumerable<User> GetAll()
        {
            return context.Users.ToList();
        }
        
        public void Add(User entity)
        {
            context.Users.Add(entity);
            cache.Add(entity);
        }
        
        public void Delete(int id)
        {
            var user = GetById(id);
            if (user != null)
            {
                context.Users.Remove(user);
            }
        }
        
        private void ClearCache()
        {
            cache.Clear();
        }
    }
}
        